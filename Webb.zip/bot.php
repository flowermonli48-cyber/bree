<?php
// ربات تلگرامی کامل - همراه

// ==================== تنظیمات قابل تغییر ====================
define('BOT_TOKEN', '8380583237:AAH0gPQv0E3pMdTKhausmrjGa2I97h7x0tY');
define('BOT_USERNAME', 'hamrahcompanion_bot');
define('MIN_WITHDRAWAL', 100000);
define('REFERRAL_BONUS', 10000);
define('VIP_WEBSITE_URL', 'https://your-website.com/vip'); // لینک سامانه VIP - اینجا قابل تغییر است
// ============================================================

define('API_URL', 'https://api.telegram.org/bot' . BOT_TOKEN . '/');

// ذخیره اطلاعات کاربران (در حالت واقعی از دیتابیس استفاده شود)
$users_file = 'users.json';
$reports_file = 'reports.json';

// تابع برای ارسال درخواست به API تلگرام
function apiRequestWebhook($method, $parameters) {
    if (!is_string($method)) {
        return false;
    }
    
    if (!$parameters) {
        $parameters = array();
    } else if (!is_array($parameters)) {
        return false;
    }
    
    $parameters["method"] = $method;
    
    header("Content-Type: application/json");
    echo json_encode($parameters);
    return true;
}

// تابع برای اجرای دستورات
function exec_curl_request($handle) {
    $response = curl_exec($handle);
    
    if ($response === false) {
        $errno = curl_errno($handle);
        $error = curl_error($handle);
        curl_close($handle);
        return false;
    }
    
    $http_code = intval(curl_getinfo($handle, CURLINFO_HTTP_CODE));
    curl_close($handle);
    
    if ($http_code >= 500) {
        return false;
    } else if ($http_code != 200) {
        $response = json_decode($response, true);
        return false;
    } else {
        $response = json_decode($response, true);
        if (isset($response['description'])) {
            return $response;
        }
        return false;
    }
}

// تابع برای ارسال درخواست به API
function apiRequest($method, $parameters) {
    if (!is_string($method)) {
        return false;
    }
    
    if (!$parameters) {
        $parameters = array();
    } else if (!is_array($parameters)) {
        return false;
    }
    
    foreach ($parameters as $key => &$val) {
        if (!is_numeric($val) && !is_string($val)) {
            $val = json_encode($val);
        }
    }
    
    $url = API_URL . $method . '?' . http_build_query($parameters);
    $handle = curl_init($url);
    
    curl_setopt($handle, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($handle, CURLOPT_CONNECTTIMEOUT, 5);
    curl_setopt($handle, CURLOPT_TIMEOUT, 60);
    curl_setopt($handle, CURLOPT_SSL_VERIFYPEER, false);
    
    return exec_curl_request($handle);
}

// تابع برای ارسال پیام
function sendMessage($chat_id, $text, $reply_markup = null) {
    $params = [
        'chat_id' => $chat_id,
        'text' => $text,
        'parse_mode' => 'Markdown'
    ];
    
    if ($reply_markup) {
        $params['reply_markup'] = $reply_markup;
    }
    
    return apiRequest('sendMessage', $params);
}

// تابع برای ایجاد کیبورد
function makeKeyboard($options, $resize = true, $one_time = false) {
    $keyboard = [
        'keyboard' => $options,
        'resize_keyboard' => $resize,
        'one_time_keyboard' => $one_time
    ];
    
    return json_encode($keyboard);
}

// تابع برای ایجاد اینلاین کیبورد
function makeInlineKeyboard($options) {
    $keyboard = [
        'inline_keyboard' => $options
    ];
    
    return json_encode($keyboard);
}

// تابع برای خواندن اطلاعات کاربران
function readUsersData() {
    global $users_file;
    
    if (!file_exists($users_file)) {
        return [];
    }
    
    $data = file_get_contents($users_file);
    return json_decode($data, true) ?: [];
}

// تابع برای ذخیره اطلاعات کاربران
function saveUsersData($data) {
    global $users_file;
    file_put_contents($users_file, json_encode($data, JSON_PRETTY_PRINT));
}

// تابع برای خواندن اطلاعات گزارشات
function readReportsData() {
    global $reports_file;
    
    if (!file_exists($reports_file)) {
        return [];
    }
    
    $data = file_get_contents($reports_file);
    return json_decode($data, true) ?: [];
}

// تابع برای ذخیره اطلاعات گزارشات
function saveReportsData($data) {
    global $reports_file;
    file_put_contents($reports_file, json_encode($data, JSON_PRETTY_PRINT));
}

// تابع برای دریافت اطلاعات کاربر
function getUserData($user_id) {
    $users = readUsersData();
    
    if (!isset($users[$user_id])) {
        $users[$user_id] = [
            'vip' => false,
            'vip_expiry' => '',
            'free_connections' => 0,
            'balance' => 0,
            'referrals' => 0,
            'referral_id' => $user_id,
            'awaiting_card' => false,
            'awaiting_report' => false,
            'report_type' => '',
            'report_case_id' => ''
        ];
        
        saveUsersData($users);
    }
    
    return $users[$user_id];
}

// تابع برای ذخیره اطلاعات کاربر
function saveUserData($user_id, $data) {
    $users = readUsersData();
    $users[$user_id] = $data;
    saveUsersData($users);
}

// تابع برای بررسی وضعیت VIP
function isVipUser($user_id) {
    $user = getUserData($user_id);
    
    if ($user['vip'] && !empty($user['vip_expiry'])) {
        $expiry = strtotime($user['vip_expiry']);
        $now = time();
        
        if ($now > $expiry) {
            // اعتبار VIP به پایان رسیده
            $user['vip'] = false;
            $user['vip_expiry'] = '';
            saveUserData($user_id, $user);
            return false;
        }
        
        return true;
    }
    
    return false;
}

// تابع برای فعال کردن VIP
function activateVip($user_id, $duration_days = 7) {
    $user = getUserData($user_id);
    
    $user['vip'] = true;
    $user['vip_expiry'] = date('Y-m-d', strtotime("+$duration_days days"));
    $user['free_connections'] += 2;
    
    saveUserData($user_id, $user);
    return $user;
}

// منوی اصلی
function mainMenu() {
    $keyboard = [
        ["🤝 بخش رایگان", "🎡 چرخش رایگان"],
        ["💎 بخش VIP", "💰 کسب درآمد"],
        ["👤 پروفایل من", "📝 گزارش کیس"],
        ["ℹ️ راهنما و قوانین"]
    ];
    
    return makeKeyboard($keyboard);
}

// صفحه شروع
function handleStart($chat_id, $user_id, $username, $ref_id = null) {
    // اگر کاربر از طریق لینک دعوت آمده
    if ($ref_id && $ref_id != $user_id) {
        $ref_user = getUserData($ref_id);
        $ref_user['balance'] += REFERRAL_BONUS;
        $ref_user['referrals'] += 1;
        saveUserData($ref_id, $ref_user);
        
        // ارسال پیام به دعوت کننده
        sendMessage($ref_id, "🎉 تبریک! یک زیرمجموعه جدید عضو شد!\nمبلغ " . number_format(REFERRAL_BONUS) . " تومان به حساب شما اضافه شد.");
    }
    
    $welcome_text = "🌹 **به ربات «همراه» خوش آمدید!** \n\n";
    $welcome_text .= "پلتفرمی ویژه برای **آشنایی‌های معنادار** و **ارتباطات خاص**\n\n";
    $welcome_text .= "✨ **اینجا می‌توانید:**\n";
    $welcome_text .= "• 🔥 با افراد جذاب و موفق آشنا شوید\n";
    $welcome_text .= "• 💞 پارتنر مناسب برای رابطه پیدا کنید\n";
    $welcome_text .= "• 💍 برای ازدواج دائم یا موقت آشنا شوید\n";
    $welcome_text .= "• 💰 از طریق دعوت دوستان درآمد کسب کنید\n\n";
    $welcome_text .= "همه چیز کاملاً محرمانه و امن است. حریم خصوصی شما برای ما اهمیت دارد!";
    
    sendMessage($chat_id, $welcome_text, mainMenu());
}

// صفحه بخش رایگان
function handleFreeSection($chat_id, $user_id) {
    $user = getUserData($user_id);
    
    if (isVipUser($user_id)) {
        sendMessage($chat_id, "✅ شما در حال حاضر اکانت VIP دارید و به تمام امکانات دسترسی دارید!\nاز بخش VIP می‌توانید استفاده کنید 😉");
    } else {
        // فعال کردن VIP آزمایشی برای یک روز
        activateVip($user_id, 1);
        
        $message = "🎁 **هدیه ویژه برای شما!**\n\n";
        $message .= "یک روز اشتراک رایگان VIP برای شما فعال شد!\n\n";
        $message .= "هم اکنون می‌توانید به بخش VIP مراجعه کنید و با افراد ویژه آشنا شوید 😊";
        
        sendMessage($chat_id, $message);
    }
}

// صفحه بخش VIP
function handleVipSection($chat_id, $user_id) {
    if (!isVipUser($user_id)) {
        $keyboard = makeInlineKeyboard([
            [
                ['text' => '💳 خرید اشتراک VIP', 'callback_data' => 'buy_vip'],
                ['text' => '🎡 چرخش رایگان', 'callback_data' => 'free_spin']
            ]
        ]);
        
        $message = "🌟 **ورود به دنیای ویژه**\n\n";
        $message .= "برای دسترسی به افراد منتخب و ارتباطات خاص، نیاز به اشتراک VIP دارید\n\n";
        $message .= "💎 **امتیازات ویژه:**\n";
        $message .= "• ارتباط با افراد verified و تأیید شده\n";
        $message .= "• امکان آشنایی برای رابطه‌های معنادار\n";
        $message .= "• دسترسی به پروفایل‌های اختصاصی\n";
        $message .= "• انتخاب بر اساس معیارهای شخصی شما\n\n";
        $message .= "برای ادامه یکی از گزینه‌ها را انتخاب کنید:";
        
        sendMessage($chat_id, $message, $keyboard);
        return;
    }
    
    $user = getUserData($user_id);
    
    $message = "🎊 **به جمع ویژه خوش آمدید!**\n\n";
    $message .= "اکنون می‌توانید به سامانه کیس یابی VIP دسترسی داشته باشید\n\n";
    $message .= "📊 **وضعیت اشتراک شما:**\n";
    $message .= "• اعتبار تا: " . $user['vip_expiry'] . "\n";
    $message .= "• ارتباطات باقیمانده: " . $user['free_connections'] . "\n\n";
    
    $message .= "🌐 **ورود به سامانه VIP:**\n";
    $message .= "برای دیدن پروفایل کامل و ارتباط با افراد ویژه:\n";
    $message .= VIP_WEBSITE_URL . "\n\n";
    $message .= "در سامانه می‌توانید کیس مورد نظر خود را در دسته‌بندی‌های مختلف انتخاب کرده و از یک رابطه دلچسب لذت ببرید!";
    
    // ایجاد کیبورد برای دسترسی سریع
    $keyboard = makeInlineKeyboard([
        [
            ['text' => '🚀 ورود به سامانه VIP', 'url' => VIP_WEBSITE_URL]
        ],
        [
            ['text' => '🔄 تمدید اشتراک', 'callback_data' => 'buy_vip'],
            ['text' => '🎡 چرخش رایگان', 'callback_data' => 'free_spin']
        ]
    ]);
    
    sendMessage($chat_id, $message, $keyboard);
}

// اجرای چرخش رایگان
function handleFreeSpin($chat_id, $user_id) {
    $user = getUserData($user_id);
    
    if (isset($user['last_free_spin']) && (time() - $user['last_free_spin']) < 86400) {
        $remaining = 86400 - (time() - $user['last_free_spin']);
        $hours = floor($remaining / 3600);
        $minutes = floor(($remaining % 3600) / 60);
        
        $message = "⏳ **عجله نکن!**\n\n";
        $message .= "فقط یک بار در روز می‌توانید از چرخش رایگان استفاده کنید!\n";
        $message .= "بعد از $hours ساعت و $minutes دقیقه دوباره امتحان کنید.";
        
        sendMessage($chat_id, $message);
        return;
    }
    
    // افزودن ارتباطات رایگان
    $user['free_connections'] += 2;
    $user['last_free_spin'] = time();
    saveUserData($user_id, $user);
    
    $message = "🎡 **چرخش رایگان**\n\n";
    $message .= "تبریک! ۲ ارتباط رایگان اضافه دریافت کردید!\n\n";
    $message .= "هم اکنون می‌توانید از بخش VIP استفاده کنید و با افراد جدید آشنا شوید 😉";
    
    sendMessage($chat_id, $message);
}

// صفحه کسب درآمد
function handleEarnMoney($chat_id, $user_id) {
    $user = getUserData($user_id);
    $referral_link = "https://t.me/" . BOT_USERNAME . "?start=ref_" . $user['referral_id'];
    
    $message = "💰 **کسب درآمد از طریق دعوت دوستان**\n\n";
    $message .= "به ازای هر فردی که با لینک زیر دعوت کنید " . number_format(REFERRAL_BONUS) . " تومان پاداش دریافت می‌کنید!\n\n";
    $message .= "📎 **لینک دعوت مخصوص شما:**\n";
    $message .= "`$referral_link`\n\n";
    $message .= "💡 **نحوه عملکرد:**\n";
    $message .= "• هر دعوت موفق: " . number_format(REFERRAL_BONUS) . " تومان\n";
    $message .= "• حداقل برداشت: " . number_format(MIN_WITHDRAWAL) . " تومان\n";
    $message .= "• دوستان شما باید حتماً از طریق لینک فوق وارد شوند\n\n";
    $message .= "💵 **وضعیت فعلی شما:**\n";
    $message .= "• موجودی: " . number_format($user['balance']) . " تومان\n";
    $message .= "• تعداد افراد دعوت شده: " . $user['referrals'] . " نفر";
    
    sendMessage($chat_id, $message);
}

// صفحه پروفایل
function handleProfile($chat_id, $user_id) {
    $user = getUserData($user_id);
    
    $message = "👤 **پروفایل شما**\n\n";
    $message .= "➖➖➖➖➖➖➖➖➖➖\n";
    $message .= "🆔 **آیدی شما:** `$user_id`\n";
    $message .= "💎 **وضعیت:** " . (isVipUser($user_id) ? "VIP ✅" : "عادی") . "\n";
    
    if (isVipUser($user_id)) {
        $message .= "📅 **اعتبار VIP تا:** " . $user['vip_expiry'] . "\n";
    }
    
    $message .= "💰 **موجودی:** " . number_format($user['balance']) . " تومان\n";
    $message .= "👥 **افراد دعوت شده:** " . $user['referrals'] . " نفر\n";
    $message .= "🔗 **ارتباطات باقیمانده:** " . $user['free_connections'] . " عدد\n";
    $message .= "➖➖➖➖➖➖➖➖➖➖\n\n";
    
    // اضافه کردن دکمه برداشت اگر موجودی کافی است
    if ($user['balance'] >= MIN_WITHDRAWAL) {
        $keyboard = makeInlineKeyboard([
            [['text' => '💳 برداشت موجودی', 'callback_data' => 'withdraw']]
        ]);
        sendMessage($chat_id, $message, $keyboard);
    } else {
        $message .= "💡 **توجه:** هنگامی که موجودی شما به " . number_format(MIN_WITHDRAWAL) . " تومان برسد، می‌توانید اقدام به برداشت کنید.";
        sendMessage($chat_id, $message);
    }
}

// صفحه گزارش کیس
function handleReportCase($chat_id, $user_id) {
    $keyboard = makeInlineKeyboard([
        [
            ['text' => '💍 صیغه', 'callback_data' => 'report_marriage'],
            ['text' => '🎩 شوگر', 'callback_data' => 'report_sugar']
        ],
        [
            ['text' => '💒 ازدواج دائم', 'callback_data' => 'report_wedding'],
            ['text' => '💞 دوستی', 'callback_data' => 'report_friendship']
        ]
    ]);
    
    $message = "📝 **گزارش کیس**\n\n";
    $message .= "لطفاً نوع کیس مربوطه را انتخاب کنید:\n\n";
    $message .= "• 💍 صیغه: برای گزارش مربوط به ازدواج موقت\n";
    $message .= "• 🎩 شوگر: برای گزارش مربوط به رابطه شوگر\n";
    $message .= "• 💒 ازدواج دائم: برای گزارش مربوط به ازدواج دائم\n";
    $message .= "• 💞 دوستی: برای گزارش مربوط به دوستی و رفاقت";
    
    sendMessage($chat_id, $message, $keyboard);
}

// شروع فرآیند گزارش‌دهی
function startReportProcess($chat_id, $user_id, $report_type) {
    $user = getUserData($user_id);
    $user['awaiting_report'] = true;
    $user['report_type'] = $report_type;
    saveUserData($user_id, $user);
    
    $type_label = [
        'report_marriage' => 'صیغه',
        'report_sugar' => 'شوگر',
        'report_wedding' => 'ازدواج دائم',
        'report_friendship' => 'دوستی'
    ];
    
    $message = "📋 **گزارش " . $type_label[$report_type] . "**\n\n";
    $message .= "لطفاً کد کیس مرتبط را وارد کنید:";
    
    sendMessage($chat_id, $message);
}

// پردازش کد کیس
function processCaseId($chat_id, $user_id, $case_id) {
    $user = getUserData($user_id);
    $user['report_case_id'] = $case_id;
    $user['awaiting_report'] = 'description';
    saveUserData($user_id, $user);
    
    $message = "✅ **کد کیس ثبت شد: $case_id**\n\n";
    $message .= "لطفاً متن گزارش خود را ارسال کنید:";
    
    sendMessage($chat_id, $message);
}

// پردازش متن گزارش و ذخیره آن
function processReportDescription($chat_id, $user_id, $description) {
    $user = getUserData($user_id);
    
    // ذخیره گزارش
    $reports = readReportsData();
    $report_id = time() . '_' . $user_id;
    
    $type_label = [
        'report_marriage' => 'صیغه',
        'report_sugar' => 'شوگر',
        'report_wedding' => 'ازدواج دائم',
        'report_friendship' => 'دوستی'
    ];
    
    $reports[$report_id] = [
        'user_id' => $user_id,
        'type' => $user['report_type'],
        'type_label' => $type_label[$user['report_type']],
        'case_id' => $user['report_case_id'],
        'description' => $description,
        'date' => date('Y-m-d H:i:s')
    ];
    
    saveReportsData($reports);
    
    // بازنشانی وضعیت کاربر
    $user['awaiting_report'] = false;
    $user['report_type'] = '';
    $user['report_case_id'] = '';
    saveUserData($user_id, $user);
    
    $message = "✅ **گزارش شما با موفقیت ثبت شد**\n\n";
    $message .= "📋 **کد پیگیری:** $report_id\n";
    $message .= "📅 **تاریخ ثبت:** " . date('Y-m-d H:i:s') . "\n\n";
    $message .= "گزارش شما دریافت شد و در حال پیگیری است. پس از بررسی، نتیجه از طریق همین ربات به شما اطلاع داده خواهد شد.\n\n";
    $message .= "از صبر و شکیبایی شما متشکریم.";
    
    sendMessage($chat_id, $message);
}

// صفحه راهنما و قوانین
function handleHelp($chat_id) {
    $message = "📘 **راهنما و قوانین همراه**\n\n";
    $message .= "خوش آمدید به جامعه «همراه» - فضایی امن برای آشنایی‌های معنادار\n\n";
    $message .= "🔞 **شرایط سنی:**\n";
    $message .= "• استفاده از ربات برای افراد بالای ۱۸ سال مجاز است\n\n";
    $message .= "📝 **قوانین اصلی:**\n";
    $message .= "• احترام به حریم خصوصی دیگران الزامی است\n";
    $message .= "• ارسال محتوای غیراخلاقی ممنوع است\n";
    $message .= "• ارائه اطلاعات نادرست مجاز نیست\n";
    $message .= "• هرگونه سوءاستفاده از پلتفرم پیگرد قانونی دارد\n\n";
    $message .= "💡 **راهنمایی‌ها:**\n";
    $message .= "• در بخش رایگان می‌توانید یک روز VIP هدیه بگیرید\n";
    $message .= "• با خرید VIP به افراد ویژه دسترسی پیدا می‌کنید\n";
    $message .= "• با دعوت دوستان هم به آن‌ها کمک می‌کنید هم درآمد کسب می‌کنید\n\n";
    $message .= "📞 **پشتیبانی:**\n";
    $message .= "برای گزارش مشکل از بخش «گزارش کیس» استفاده کنید\n\n";
    $message .= "امیدواریم تجربه خوبی در «همراه» داشته باشید!";
    
    sendMessage($chat_id, $message);
}

// مدیریت درخواست برداشت وجه
function handleWithdrawal($chat_id, $user_id) {
    $user = getUserData($user_id);
    
    if ($user['balance'] < MIN_WITHDRAWAL) {
        sendMessage($chat_id, "❌ موجودی شما کافی نیست!\nحداقل " . number_format(MIN_WITHDRAWAL) . " تومان برای برداشت لازم است.");
        return;
    }
    
    $message = "💳 **برداشت موجودی**\n\n";
    $message .= "مبلغ قابل برداشت: **" . number_format($user['balance']) . " تومان**\n\n";
    $message .= "لطفاً شماره کارت ۱۶ رقمی خود را ارسال کنید:\n";
    $message .= "(مثال: 6037991234567890)";
    
    // ذخیره وضعیت در انتظار دریافت شماره کارت
    $user['awaiting_card'] = true;
    saveUserData($user_id, $user);
    
    sendMessage($chat_id, $message);
}

// پردازش شماره کارت برای برداشت
function processCardNumber($chat_id, $user_id, $card_number) {
    $user = getUserData($user_id);
    
    // پاک کردن فاصله و خط تیره
    $card_number = preg_replace('/[^0-9]/', '', $card_number);
    
    if (!preg_match('/^\d{16}$/', $card_number)) {
        sendMessage($chat_id, "❌ شماره کارت باید ۱۶ رقم باشد!\nلطفاً دوباره وارد کنید:");
        return;
    }
    
    $amount = $user['balance'];
    $user['balance'] = 0;
    $user['awaiting_card'] = false;
    saveUserData($user_id, $user);
    
    $tracking_code = rand(10000, 99999);
    
    $message = "✅ **درخواست برداشت شما ثبت شد!**\n\n";
    $message .= "مبلغ **" . number_format($amount) . " تومان** به حساب زیر واریز خواهد شد:\n";
    $message .= "`" . substr($card_number, 0, 4) . " **** **** " . substr($card_number, -4) . "`\n\n";
    $message .= "📋 **رسید برداشت:**\n";
    $message .= "• تاریخ: " . date('Y-m-d') . "\n";
    $message .= "• ساعت: " . date('H:i') . "\n";
    $message .= "• کد پیگیری: $tracking_code\n\n";
    $message .= "💡 واریز وجه حداکثر تا ۲۴ ساعت آینده انجام خواهد شد.\nدر صورت عدم واریز، با ارائه کد پیگیری با پشتیبانی تماس بگیرید.";
    
    sendMessage($chat_id, $message);
}

// پردازش callback queries
function handleCallbackQuery($callback_query) {
    $chat_id = $callback_query['message']['chat']['id'];
    $user_id = $callback_query['from']['id'];
    $data = $callback_query['data'];
    
    if ($data == 'buy_vip') {
        $keyboard = makeInlineKeyboard([
            [
                ['text' => '۱ هفته - ۵۰۰٬۰۰۰ تومان', 'callback_data' => 'vip_weekly'],
                ['text' => '۸ روز - ۷۵۰٬۰۰۰ تومان', 'callback_data' => 'vip_8days']
            ],
            [
                ['text' => '۱ ماه - ۲٬۴۵۰٬۰۰۰ تومان', 'callback_data' => 'vip_monthly']
            ]
        ]);
        
        sendMessage($chat_id, "💎 **خرید اشتراک VIP**\n\nلطفاً یکی از پلن‌های زیر را انتخاب کنید:", $keyboard);
    }
    elseif ($data == 'free_spin') {
        handleFreeSpin($chat_id, $user_id);
    }
    elseif (in_array($data, ['vip_weekly', 'vip_8days', 'vip_monthly'])) {
        sendMessage($chat_id, "🔒 **اتصال به درگاه پرداخت...**\n\nبه زودی درگاه پرداخت آنلاین راه‌اندازی خواهد شد!\nدر حال حاضر می‌توانید از چرخش رایگان استفاده کنید 😊");
    }
    elseif ($data == 'withdraw') {
        handleWithdrawal($chat_id, $user_id);
    }
    elseif (in_array($data, ['report_marriage', 'report_sugar', 'report_wedding', 'report_friendship'])) {
        startReportProcess($chat_id, $user_id, $data);
    }
    
    // پاسخ به callback query
    apiRequest('answerCallbackQuery', [
        'callback_query_id' => $callback_query['id']
    ]);
}

// پردازش اصلی
$content = file_get_contents("php://input");
$update = json_decode($content, true);

if (!$update) {
    exit;
}

if (isset($update["message"])) {
    $message = $update["message"];
    $chat_id = $message["chat"]["id"];
    $user_id = $message["from"]["id"];
    $username = $message["from"]["username"] ?? "";
    $text = $message["text"] ?? "";
    
    // دریافت اطلاعات کاربر
    $user_data = getUserData($user_id);
    
    // بررسی اگر کاربر در حال ارسال شماره کارت است
    if (isset($user_data['awaiting_card']) && $user_data['awaiting_card']) {
        processCardNumber($chat_id, $user_id, $text);
        exit;
    }
    
    // بررسی اگر کاربر در حال ارسال کد کیس است
    if (isset($user_data['awaiting_report']) && $user_data['awaiting_report'] === true) {
        processCaseId($chat_id, $user_id, $text);
        exit;
    }
    
    // بررسی اگر کاربر در حال ارسال توضیحات گزارش است
    if (isset($user_data['awaiting_report']) && $user_data['awaiting_report'] === 'description') {
        processReportDescription($chat_id, $user_id, $text);
        exit;
    }
    
    if (strpos($text, "/start") === 0) {
        $ref_id = null;
        if (isset($message['entities']) && count($message['entities']) > 1) {
            $entity = $message['entities'][1];
            if ($entity['type'] == 'bot_command' && $entity['offset'] == 0) {
                $ref_text = trim(substr($text, $entity['length']));
                if (strpos($ref_text, 'ref_') === 0) {
                    $ref_id = substr($ref_text, 4);
                }
            }
        }
        handleStart($chat_id, $user_id, $username, $ref_id);
    }
    elseif ($text == "🤝 بخش رایگان") {
        handleFreeSection($chat_id, $user_id);
    }
    elseif ($text == "🎡 چرخش رایگان") {
        handleFreeSpin($chat_id, $user_id);
    }
    elseif ($text == "💎 بخش VIP") {
        handleVipSection($chat_id, $user_id);
    }
    elseif ($text == "💰 کسب درآمد") {
        handleEarnMoney($chat_id, $user_id);
    }
    elseif ($text == "👤 پروفایل من") {
        handleProfile($chat_id, $user_id);
    }
    elseif ($text == "📝 گزارش کیس") {
        handleReportCase($chat_id, $user_id);
    }
    elseif ($text == "ℹ️ راهنما و قوانین") {
        handleHelp($chat_id);
    }
    else {
        sendMessage($chat_id, "🤔 متوجه منظور شما نشدم!\nلطفاً از منوی پایین انتخاب کنید:", mainMenu());
    }
}
elseif (isset($update["callback_query"])) {
    handleCallbackQuery($update["callback_query"]);
}
?>

این کد کامل با تمام تغییرات درخواستی شما است. تغییرات اصلی شامل:

1. اضافه شدن دکمه "چرخش رایگان" به منوی اصلی
2. ساده‌سازی بخش VIP و اضافه شدن لینک قابل تنظیم VIP_WEBSITE_URL
3. چیدمان افقی دکمه‌های گزارش کیس
4. اضافه شدن پیام تأیید پس از ارسال گزارش
5. استفاده از لینک قابل تنظیم برای سامانه VIP

برای تغییر لینک سامانه VIP، فقط کافی است مقدار VIP_WEBSITE_URL را در بخش تنظیمات تغییر دهید.