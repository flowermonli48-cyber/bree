
import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import NavBar from '../../../components/base/NavBar';
import TabBar from '../../../components/base/TabBar';
import SettingsModal from './components/SettingsModal';
import { casesAPI, type CaseData } from '../../../lib/supabase';
import { generateCompleteCase } from '../../../data/caseDataBank';

export default function AdminDashboard() {
  const navigate = useNavigate();

  const [cases, setCases] = useState<CaseData[]>([]);
  const [loading, setLoading] = useState(false); // تغییر: شروع با false
  const [showCasesModal, setShowCasesModal] = useState(false);
  const [showSettingsModal, setShowSettingsModal] = useState(false);
  const [showImageUploadModal, setShowImageUploadModal] = useState(false);
  const [showImageGallery, setShowImageGallery] = useState(false);
  const [selectedCaseForGallery, setSelectedCaseForGallery] = useState<CaseData | null>(null);
  const [galleryCurrentIndex, setGalleryCurrentIndex] = useState(0);

  const openImageGallery = (caseItem: CaseData) => {
    setSelectedCaseForGallery(caseItem);
    setGalleryCurrentIndex(0);
    setShowImageGallery(true);
  };

  const closeImageGallery = () => {
    setShowImageGallery(false);
    setSelectedCaseForGallery(null);
    setGalleryCurrentIndex(0);
  };

  // States برای مدیریت آگهی‌ها
  const [casesCurrentPage, setCasesCurrentPage] = useState(1);
  const [casesTotalPages, setCasesTotalPages] = useState(0);
  const [casesPerPage] = useState(50);
  const [casesDisplayed, setCasesDisplayed] = useState<CaseData[]>([]);
  const [casesLoading, setCasesLoading] = useState(false);

  // فرم آپلود عکس
  const [uploadForm, setUploadForm] = useState({
    images: [] as string[],
    uploading: false
  });

  // **بخش جدید: تغییر مشخصات آگهی**
  const [showEditModal, setShowEditModal] = useState(false);
  const [editingCase, setEditingCase] = useState<CaseData | null>(null);
  const [editForm, setEditForm] = useState({
    name: '',
    location: ''
  });

  // لیست کامل 31 استان ایران
  const IRANIAN_PROVINCES = [
    'تهران', 'اصفهان', 'خراسان رضوی', 'فارس', 'آذربایجان شرقی', 'خوزستان', 'مازندران',
    'گیلان', 'کرمان', 'البرز', 'هرمزگان', 'سیستان و بلوچستان', 'همدان', 'زنجان',
    'یزد', 'اردبیل', 'لرستان', 'مرکزی', 'ایلام', 'بوشهر', 'کردستان', 'آذربایجان غربی',
    'قم', 'قزوین', 'گلستان', 'چهارمحال و بختیاری', 'خراسان شمالی', 'خراسان جنوبی',
    'کهگیلویه و بویراحمد', 'سمنان', 'کرمانشاه'
  ];

  const openEditModal = (caseItem: CaseData) => {
    setEditingCase(caseItem);
    setEditForm({
      name: caseItem.name,
      location: caseItem.location
    });
    setShowEditModal(true);
  };

  const closeEditModal = () => {
    setShowEditModal(false);
    setEditingCase(null);
    setEditForm({ name: '', location: '' });
  };

  const handleEditSubmit = async () => {
    if (!editingCase) return;
    
    if (!editForm.name.trim() || !editForm.location.trim()) {
      alert('لطفاً تمامی فیلدها را پر کنید');
      return;
    }

    try {
      const updatedCase = await casesAPI.update(editingCase.id, {
        name: editForm.name.trim(),
        location: editForm.location.trim()
      });

      if (updatedCase) {
        const successDiv = document.createElement('div');
        successDiv.className = 'fixed top-20 left-4 right-4 bg-gradient-to-r from-green-500 to-emerald-600 text-white px-6 py-4 rounded-2xl shadow-xl z-50 text-center font-semibold';
        successDiv.innerHTML = `
          <div class="text-center">
            <i class="ri-edit-2-line text-2xl mb-2"></i>
            <div class="font-bold text-lg mb-1">✅ مشخصات آگهی به‌روزرسانی شد!</div>
            <div class="text-sm opacity-90">نام: ${updatedCase.name} • استان: ${updatedCase.location}</div>
            <div class="text-xs opacity-80 mt-1">⚠️ تغییرات برای همه کاربران قابل مشاهده است</div>
          </div>
        `;
        document.body.appendChild(successDiv);
        
        setTimeout(() => {
          if (document.body.contains(successDiv)) {
            document.body.removeChild(successDiv);
          }
        }, 5000);

        closeEditModal();
        loadAllCases(); // رفرش لیست
      } else {
        throw new Error('خطا در به‌روزرسانی');
      }
    } catch (error) {
      console.error('❌ خطا در ویرایش آگهی:', error);
      
      const errorDiv = document.createElement('div');
      errorDiv.className = 'fixed top-20 left-4 right-4 bg-gradient-to-r from-red-500 to-pink-600 text-white px-6 py-4 rounded-2xl shadow-xl z-50 text-center font-semibold';
      errorDiv.innerHTML = `
        <div class="flex items-center justify-center">
          <i class="ri-error-warning-line text-xl ml-2"></i>
          <span>خطا در ویرایش آگهی! لطفاً دوباره تلاش کنید</span>
        </div>
      `;
      document.body.appendChild(errorDiv);
      
      setTimeout(() => {
        if (document.body.contains(errorDiv)) {
          document.body.removeChild(errorDiv);
        }
      }, 4000);
    }
  };

  useEffect(() => {
    checkAdminAuth();
    // حذف loadAllCases از اینجا - فقط وقتی کاربر بخواهد لود میشه
  }, []);

  const checkAdminAuth = () => {
    const adminToken = localStorage.getItem('adminToken');
    if (!adminToken) {
      navigate('/admin/login');
      return;
    }
  };

  // **اصلاح: بارگذاری فقط وقتی کاربر کلیک کنه**
  const loadAllCases = async () => {
    if (loading) return; // جلوگیری از multiple calls
    
    setLoading(true);
    try {
      console.log('🔄 بارگذاری آگهی‌های موجود از Supabase...');
      
      const allCasesData = await casesAPI.getAllForAdmin();
      setCases(allCasesData);
      
      console.log(`✅ ${allCasesData.length} آگهی موجود از دیتابیس بارگذاری شد`);
      
    } catch (error) {
      console.error('❌ خطا در بارگذاری آگهی‌ها:', error);
      setCases([]);
    }
    setLoading(false);
  };

  // ثبت خودکار
  const quickAddCase = async () => {
    try {
      // **اضافه کردن لاگ برای بررسی تولید**
      console.log('🔄 شروع تولید آگهی جدید...');
      const newCase = generateCompleteCase();
      console.log(`📊 آگهی تولید شده - نوع: ${newCase.category}, استان: ${newCase.location}`);

      const createdCase = await casesAPI.create({
        name: newCase.name,
        image: newCase.image,
        location: newCase.location,
        category: newCase.category || 'temporary',
        price: newCase.price || 0,
        age: newCase.age || 25,
        height: newCase.height,
        skin_color: newCase.skin_color,
        body_type: newCase.body_type,
        personality_traits: newCase.personality_traits,
        experience_level: newCase.experience_level,
        description: newCase.description,
        status: 'active',
        verified: true,
        online: true,
        is_persistent: true,
        details: newCase.details,
        comments: newCase.comments || []
      });

      if (createdCase) {
        // **بهبود پیام موفقیت با نمایش نوع کیس**
        const categoryName = getCategoryName(createdCase.category);
        
        const successDiv = document.createElement('div');
        successDiv.className = 'fixed top-20 left-4 right-4 bg-gradient-to-r from-green-500 to-emerald-600 text-white px-6 py-4 rounded-2xl shadow-xl z-50 text-center font-semibold';
        successDiv.innerHTML = `
          <div class="text-center">
            <i class="ri-check-double-line text-2xl mb-2"></i>
            <div class="font-bold text-lg mb-1">✅ آگهی جدید ثبت شد!</div>
            <div class="text-sm opacity-90">نام: ${createdCase.name} • استان: ${createdCase.location}</div>
            <div class="text-xs opacity-80 mt-1">نوع کیس: ${categoryName}</div>
          </div>
        `;
        document.body.appendChild(successDiv);
        
        setTimeout(() => {
          if (document.body.contains(successDiv)) {
            document.body.removeChild(successDiv);
          }
        }, 4000);

        loadAllCases(); // رفرش لیست
      } else {
        throw new Error('خطا در ایجاد آگهی');
      }
    } catch (error) {
      console.error('❌ خطا در ثبت آگهی:', error);
      
      const errorDiv = document.createElement('div');
      errorDiv.className = 'fixed top-20 left-4 right-4 bg-gradient-to-r from-red-500 to-pink-600 text-white px-6 py-4 rounded-2xl shadow-xl z-50 text-center font-semibold';
      errorDiv.innerHTML = `
        <div class="flex items-center justify-center">
          <i class="ri-error-warning-line text-xl ml-2"></i>
          <span>❌ خطا در ثبت آگهی! لطفاً دوباره تلاش کنید</span>
        </div>
      `;
      document.body.appendChild(errorDiv);
      
      setTimeout(() => {
        if (document.body.contains(errorDiv)) {
          document.body.removeChild(errorDiv);
        }
      }, 4000);
    }
  };

  // **اضافه کردن تابع getCategoryName در پنل ادمین**
  const getCategoryName = (category: string) => {
    const categories: { [key: string]: string } = {
      'temporary': 'صیغه موقت',
      'sighe': 'صیغه موقت', 
      'sugar': 'شوگر دیدی',
      'friendship': 'دوستی',
      'marriage': 'ازدواج موقت'
    };
    return categories[category] || 'صیغه موقت';
  };

  const startImageUpload = () => {
    setShowImageUploadModal(true);
    setUploadForm({ images: [], uploading: false });
  };

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (!files) return;

    setUploadForm(prev => ({ ...prev, uploading: true }));

    const maxImages = 5;
    const selectedFiles = Array.from(files).slice(0, maxImages);
    let processedImages: string[] = [];
    let processedCount = 0;

    selectedFiles.forEach((file) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        const result = e.target?.result as string;
        if (result) {
          processedImages.push(result);
        }
        processedCount++;

        if (processedCount === selectedFiles.length) {
          setUploadForm({
            images: processedImages,
            uploading: false
          });
        }
      };
      reader.readAsDataURL(file);
    });
  };

  const handleImageSubmit = async () => {
    if (uploadForm.images.length === 0) {
      alert('لطفاً ابتدا حداقل یک عکس آپلود کنید');
      return;
    }

    try {
      const newCase = generateCompleteCase(uploadForm.images[0]);

      const createdCase = await casesAPI.create({
        name: newCase.name,
        image: uploadForm.images[0],
        location: newCase.location,
        category: newCase.category || 'temporary',
        price: newCase.price || 0,
        age: newCase.age || 25,
        height: newCase.height,
        skin_color: newCase.skinColor,
        body_type: newCase.bodyType,
        personality_traits: newCase.personalityTraits,
        experience_level: newCase.experienceLevel,
        description: newCase.description,
        status: 'active',
        verified: true,
        online: true,
        is_persistent: true,
        details: {
          ...newCase.details,
          gallery_images: uploadForm.images
        },
        comments: newCase.comments || []
      });

      if (createdCase) {
        const successDiv = document.createElement('div');
        successDiv.className = 'fixed top-20 left-4 right-4 bg-gradient-to-r from-green-500 to-emerald-600 text-white px-6 py-4 rounded-2xl shadow-xl z-50 text-center font-semibold';
        successDiv.innerHTML = `
          <div class="text-center">
            <i class="ri-image-add-line text-2xl mb-2"></i>
            <div class="font-bold text-lg mb-1">✅ آگهی با گالری عکس ثبت شد!</div>
            <div class="text-sm opacity-90">نام: ${createdCase.name} • ${uploadForm.images.length} عکس</div>
          </div>
        `;
        document.body.appendChild(successDiv);
        
        setTimeout(() => {
          if (document.body.contains(successDiv)) {
            document.body.removeChild(successDiv);
          }
        }, 4000);

        setShowImageUploadModal(false);
        setUploadForm({ images: [], uploading: false });
        loadAllCases(); // رفرش لیست
      } else {
        throw new Error('خطا در ایجاد آگهی');
      }
    } catch (error) {
      console.error('❌ خطا در ثبت آگهی با عکس:', error);
      
      const errorDiv = document.createElement('div');
      errorDiv.className = 'fixed top-20 left-4 right-4 bg-gradient-to-r from-red-500 to-pink-600 text-white px-6 py-4 rounded-2xl shadow-xl z-50 text-center font-semibold';
      errorDiv.innerHTML = `
        <div class="flex items-center justify-center">
          <i className="ri-error-warning-line text-xl ml-2"></i>
          <span>❌ خطا در ثبت آگهی با عکس! لطفاً دوباره تلاش کنید</span>
        </div>
      `;
      document.body.appendChild(errorDiv);
      
      setTimeout(() => {
        if (document.body.contains(errorDiv)) {
          document.body.removeChild(errorDiv);
        }
      }, 4000);
    }
  };

  const removeUploadedImage = (index: number) => {
    setUploadForm(prev => ({
      ...prev,
      images: prev.images.filter((_, i) => i !== index)
    }));
  };

  // **بخش جدید: تغییر مشخصات آگهی** (به‌روزرسانی تابع)
  const updateCaseStatus = async (caseId: number, newStatus: string) => {
    try {
      const updatedCase = await casesAPI.update(caseId, { status: newStatus });
      if (updatedCase) {
        console.log(`✅ وضعیت آگهی ${caseId} به ${newStatus} تغییر کرد`);
        
        const statusMessages: { [key: string]: string } = {
          'active': 'فعال شد ✅',
          'reserved': 'رزرو شد 🟡',
          'deleted': 'حذف شد 🗑️'
        };
        
        const successDiv = document.createElement('div');
        successDiv.className = 'fixed top-20 left-4 right-4 bg-gradient-to-r from-blue-500 to-indigo-600 text-white px-6 py-4 rounded-2xl shadow-xl z-50 text-center font-semibold';
        successDiv.innerHTML = `
          <div class="flex items-center justify-center">
            <i className="ri-refresh-line text-xl ml-2"></i>
            <span>آگهی ${statusMessages[newStatus] || 'به‌روزرسانی شد'}</span>
          </div>
        `;
        document.body.appendChild(successDiv);
        
        setTimeout(() => {
          if (document.body.contains(successDiv)) {
            document.body.removeChild(successDiv);
          }
        }, 3000);

        loadAllCases(); // رفرش لیست
      }
    } catch (error) {
      console.error('❌ خطا در به‌روزرسانی وضعیت آگهی:', error);
      
      const errorDiv = document.createElement('div');
      errorDiv.className = 'fixed top-20 left-4 right-4 bg-gradient-to-r from-red-500 to-pink-600 text-white px-6 py-4 rounded-2xl shadow-xl z-50 text-center font-semibold';
      errorDiv.innerHTML = `
        <div class="flex items-center justify-center">
          <i className="ri-error-warning-line text-xl ml-2"></i>
          <span>خطا در تغییر وضعیت آگهی!</span>
        </div>
      `;
      document.body.appendChild(errorDiv);
      
      setTimeout(() => {
        if (document.body.contains(errorDiv)) {
          document.body.removeChild(errorDiv);
        }
      }, 3000);
    }
  };

  // محاسبه صفحه‌بندی آگهی‌ها
  useEffect(() => {
    const totalPages = Math.ceil(cases.length / casesPerPage);
    setCasesTotalPages(totalPages);

    const startIndex = (casesCurrentPage - 1) * casesPerPage;
    const endIndex = startIndex + casesPerPage;
    setCasesDisplayed(cases.slice(startIndex, endIndex));

    console.log(`📊 صفحه ${casesCurrentPage}: نمایش ${Math.min(casesPerPage, cases.length - startIndex)} آگهی از ${cases.length} کل آگهی`);
  }, [cases, casesCurrentPage, casesPerPage]);

  const goToCasesPage = (page: number) => {
    if (page >= 1 && page <= casesTotalPages && page !== casesCurrentPage) {
      setCasesLoading(true);
      setCasesCurrentPage(page);
      
      setTimeout(() => {
        setCasesLoading(false);
      }, 300);
    }
  };

  const nextCasesPage = () => {
    if (casesCurrentPage < casesTotalPages) {
      goToCasesPage(casesCurrentPage + 1);
    }
  };

  const prevCasesPage = () => {
    if (casesCurrentPage > 1) {
      goToCasesPage(casesCurrentPage - 1);
    }
  };

  // محاسبه آمار - فقط اگر آگهی‌ها لود شده باشن
  const activeCases = cases.filter(c => c.status === 'active');
  const totalCases = cases.length;
  const reservedCases = cases.filter(c => c.status === 'reserved').length;
  const deletedCases = cases.filter(c => c.status === 'deleted').length;

  // **حذف loading screen - مستقیم پنل رو نشون میده**
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-purple-900 to-violet-900">
      <NavBar
        title="پنل مدیریت"
        showBack={false}
        rightAction={
          <div className="flex items-center space-x-2 rtl:space-x-reverse">
            <button
              onClick={() => setShowSettingsModal(true)}
              className="w-8 h-8 flex items-center justify-center rounded-full text-gray-600 hover:bg-gray-100 transition-colors"
            >
              <i className="ri-settings-3-line text-xl"></i>
            </button>
            <button
              onClick={() => {
                localStorage.removeItem('adminToken');
                navigate('/');
                
                const logoutDiv = document.createElement('div');
                logoutDiv.className = 'fixed top-20 left-4 right-4 bg-gradient-to-r from-blue-500 to-indigo-600 text-white px-6 py-4 rounded-2xl shadow-xl z-50 text-center font-semibold';
                logoutDiv.innerHTML = `
                  <div className="flex items-center justify-center">
                    <i className="ri-logout-circle-line text-xl ml-2"></i>
                    <span>با موفقیت خارج شدید</span>
                  </div>
                `;
                document.body.appendChild(logoutDiv);
                
                setTimeout(() => {
                  if (document.body.contains(logoutDiv)) {
                    document.body.removeChild(logoutDiv);
                  }
                }, 3000);
              }}
              className="w-8 h-8 flex items-center justify-center rounded-full text-gray-600 hover:bg-gray-100 transition-colors"
            >
              <i className="ri-logout-circle-line text-xl"></i>
            </button>
          </div>
        }
      />

      <div className="pt-20 pb-20 px-4">
        {/* دکمه‌های عملیات سریع */}
        <div className="grid grid-cols-3 gap-3 mb-6">
          <button
            onClick={quickAddCase}
            className="bg-gradient-to-r from-green-600 to-emerald-700 hover:from-green-700 hover:to-emerald-800 text-white font-semibold py-4 px-3 rounded-2xl shadow-lg transition-all duration-300 hover:scale-105"
          >
            <div className="text-center">
              <i className="ri-magic-line text-2xl mb-2"></i>
              <p className="text-xs font-bold">ثبت خودکار</p>
            </div>
          </button>

          <button
            onClick={startImageUpload}
            className="bg-gradient-to-r from-blue-600 to-cyan-700 hover:from-blue-700 hover:to-cyan-800 text-white font-semibold py-4 px-3 rounded-2xl shadow-lg transition-all duration-300 hover:scale-105"
          >
            <div className="text-center">
              <i className="ri-image-add-line text-2xl mb-2"></i>
              <p className="text-xs font-bold">ثبت با عکس</p>
            </div>
          </button>

          <button
            onClick={() => {
              if (cases.length === 0) {
                loadAllCases(); // فقط اگر آگهی نداریم لود کن
              }
              setShowCasesModal(true);
            }}
            className="bg-gradient-to-r from-purple-600 to-violet-700 hover:from-purple-700 hover:to-violet-800 text-white font-semibold py-4 px-3 rounded-2xl shadow-lg transition-all duration-300 hover:scale-105"
          >
            <div className="text-center">
              <i className="ri-list-check text-2xl mb-2"></i>
              <p className="text-xs font-bold">مدیریت آگهی‌ها</p>
            </div>
          </button>
        </div>

        {/* **آمار سیستم - نمایش سریع بدون انتظار** */}
        <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-6 border border-white/20 mb-6">
          <h3 className="text-white font-bold text-lg mb-4 flex items-center">
            <i className="ri-dashboard-line ml-2 text-green-400"></i>
            داشبورد سریع
          </h3>
          
          {totalCases === 0 ? (
            <div className="text-center py-6">
              <div className="w-16 h-16 bg-white/10 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <i className="ri-database-line text-white/50 text-2xl"></i>
              </div>
              <p className="text-gray-300 mb-3">برای مشاهده آمار، ابتدا آگهی‌ها را بارگذاری کنید</p>
              <button
                onClick={loadAllCases}
                disabled={loading}
                className="bg-gradient-to-r from-blue-600 to-indigo-700 hover:from-blue-700 hover:to-indigo-800 text-white px-6 py-3 rounded-xl transition-all disabled:opacity-50"
              >
                {loading ? (
                  <div className="flex items-center">
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin ml-2"></div>
                    بارگذاری...
                  </div>
                ) : (
                  <>
                    <i className="ri-refresh-line ml-2"></i>
                    بارگذاری آگهی‌ها
                  </>
                )}
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-green-500/20 rounded-xl p-4 text-center">
                <div className="text-2xl font-bold text-green-400">{activeCases.length}</div>
                <div className="text-green-300 text-sm">آگهی فعال</div>
              </div>
              <div className="bg-blue-500/20 rounded-xl p-4 text-center">
                <div className="text-2xl font-bold text-blue-400">{totalCases}</div>
                <div className="text-blue-300 text-sm">کل آگهی‌ها</div>
              </div>
              <div className="bg-yellow-500/20 rounded-xl p-4 text-center">
                <div className="text-2xl font-bold text-yellow-400">{reservedCases}</div>
                <div className="text-yellow-300 text-sm">رزرو شده</div>
              </div>
              <div className="bg-red-500/20 rounded-xl p-4 text-center">
                <div className="text-2xl font-bold text-red-400">{deletedCases}</div>
                <div className="text-red-300 text-sm">حذف شده</div>
              </div>
            </div>
          )}
        </div>

        {/* **آخرین آگهی‌ها - نمایش اختیاری** */}
        {totalCases > 0 && (
          <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-6 border border-white/20">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-white font-bold text-lg flex items-center">
                <i className="ri-list-check ml-2"></i>
                آخرین آگهی‌ها ({totalCases} کل)
              </h3>
              <button
                onClick={loadAllCases}
                disabled={loading}
                className="bg-white/20 hover:bg-white/30 text-white px-3 py-1 rounded-lg text-sm transition-all disabled:opacity-50"
              >
                {loading ? (
                  <div className="flex items-center">
                    <div className="w-3 h-3 border-2 border-white border-t-transparent rounded-full animate-spin ml-1"></div>
                    <span>رفرش</span>
                  </div>
                ) : (
                  <>
                    <i className="ri-refresh-line ml-1"></i>
                    رفرش
                  </>
                )}
              </button>
            </div>

            <div className="space-y-3 max-h-80 overflow-y-auto">
              {cases.slice(-10).reverse().map((caseItem) => (
                <div
                  key={caseItem.id}
                  className={`p-4 rounded-xl ${
                    caseItem.status === 'deleted'
                      ? 'bg-gray-500/20'
                      : caseItem.status === 'reserved'
                      ? 'bg-yellow-500/20'
                      : 'bg-green-500/20'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <img
                        src={caseItem.image}
                        alt={caseItem.name}
                        className="w-16 h-16 rounded-2xl object-cover shadow-lg mr-3"
                        onError={(e) => {
                          const target = e.target as HTMLImageElement;
                          target.src = `https://readdy.ai/api/search-image?query=Beautiful%20Persian%20woman%20portrait&width=100&height=100&seq=${caseItem.id}&orientation=portrait`;
                        }}
                      />
                      <div className="flex-1">
                        <p className="text-white font-medium text-sm flex items-center mb-1">
                          {caseItem.name}
                          {caseItem.is_persistent && (
                            <i className="ri-bookmark-fill text-purple-400 text-xs mr-2"></i>
                          )}
                        </p>
                        <div className="text-gray-300 text-xs">
                          <div className="flex items-center">
                            <i className="ri-map-pin-line mr-1"></i>
                            <span>{caseItem.location}</span>
                            {caseItem.height && <span className="mr-2">• {caseItem.height}</span>}
                            {caseItem.age && <span className="mr-2">• {caseItem.age} ساله</span>}
                          </div>
                        </div>
                      </div>
                    </div>
                    <div
                      className={`px-3 py-1 rounded-full text-xs font-medium ${
                        caseItem.status === 'deleted'
                          ? 'bg-gray-600 text-white'
                          : caseItem.status === 'reserved'
                          ? 'bg-yellow-600 text-white'
                          : 'bg-green-600 text-white'
                      }`}
                    >
                      {caseItem.status === 'deleted'
                        ? 'حذف شده'
                        : caseItem.status === 'reserved'
                        ? 'رزرو'
                        : 'فعال'}
                    </div>
                  </div>
                </div>
              ))}
            </div>
            
            <div className="text-center mt-4">
              <button
                onClick={() => setShowCasesModal(true)}
                className="bg-gradient-to-r from-purple-600 to-violet-800 hover:from-purple-700 hover:to-violet-800 text-white px-6 py-2 rounded-xl transition-all"
              >
                <i className="ri-list-check ml-2"></i>
                مشاهده تمام {totalCases} آگهی
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Settings Modal */}
      <SettingsModal
        isOpen={showSettingsModal}
        onClose={() => setShowSettingsModal(false)}
      />

      {/* مودال مدیریت آگهی‌ها - ساده شده */}
      {showCasesModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-3xl w-full max-w-6xl max-h-[90vh] overflow-hidden shadow-2xl">
            {/* Header */}
            <div className="bg-gradient-to-r from-purple-600 to-indigo-600 text-white p-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <i className="ri-database-2-line ml-3 text-2xl"></i>
                  <div>
                    <h3 className="text-xl font-bold">مدیریت آگهی‌ها</h3>
                    <p className="text-purple-100 text-sm mt-1">
                      {cases.length} آگهی • صفحه {casesCurrentPage} از {casesTotalPages} • {activeCases.length} فعال • {reservedCases} رزرو • {deletedCases} حذف
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => {
                    setShowCasesModal(false);
                    setCasesCurrentPage(1);
                  }}
                  className="w-8 h-8 flex items-center justify-center rounded-full bg-white/20 hover:bg-white/30 transition-colors"
                >
                  <i className="ri-close-line text-lg"></i>
                </button>
              </div>

              {/* صفحه‌بندی در هدر */}
              {casesTotalPages > 1 && (
                <div className="mt-4 flex items-center justify-between">
                  <div className="flex items-center space-x-2 rtl:space-x-reverse">
                    <button
                      onClick={prevCasesPage}
                      disabled={casesCurrentPage === 1}
                      className={`px-3 py-1 rounded-lg text-sm font-medium transition-colors ${
                        casesCurrentPage === 1
                          ? 'bg-white/10 text-white/50 cursor-not-allowed'
                          : 'bg-white/20 hover:bg-white/30 text-white'
                      }`}
                    >
                      <i className="ri-arrow-right-line ml-1"></i>
                      قبلی
                    </button>

                    <div className="bg-white/20 rounded-lg px-3 py-1">
                      <span className="text-white text-sm font-medium">
                        {casesCurrentPage} / {casesTotalPages}
                      </span>
                    </div>

                    <button
                      onClick={nextCasesPage}
                      disabled={casesCurrentPage === casesTotalPages}
                      className={`px-3 py-1 rounded-lg text-sm font-medium transition-colors ${
                        casesCurrentPage === casesTotalPages
                          ? 'bg-white/10 text-white/50 cursor-not-allowed'
                          : 'bg-white/20 hover:bg-white/30 text-white'
                      }`}
                    >
                      بعدی
                      <i className="ri-arrow-left-line mr-1"></i>
                    </button>
                  </div>
                  
                  <div className="text-white/80 text-sm">
                    نمایش {((casesCurrentPage - 1) * casesPerPage) + 1} تا {Math.min(casesCurrentPage * casesPerPage, cases.length)} از {cases.length}
                  </div>
                </div>
              )}
            </div>

            {/* محتوا */}
            <div className="p-6">
              {casesLoading ? (
                <div className="text-center py-8">
                  <div className="w-8 h-8 border-2 border-purple-500 border-t-transparent rounded-full animate-spin mx-auto mb-3"></div>
                  <p className="text-gray-600">در حال بارگذاری صفحه {casesCurrentPage}...</p>
                </div>
              ) : casesDisplayed.length === 0 ? (
                <div className="text-center py-12">
                  <div className="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <i className="ri-folder-open-line text-3xl text-gray-400"></i>
                  </div>
                  <h4 className="text-lg font-bold text-gray-800 mb-2">آگهی‌ای در این صفحه یافت نشد</h4>
                  <p className="text-gray-600">به صفحه قبلی برگردید یا آگهی جدید ایجاد کنید</p>
                </div>
              ) : (
                <div className="space-y-3 max-h-[55vh] overflow-y-auto">
                  {casesDisplayed.map((caseItem) => (
                    <div
                      key={caseItem.id}
                      className="bg-gradient-to-r from-gray-50 to-white border border-gray-200 rounded-2xl p-4 hover:shadow-lg transition-all duration-300"
                    >
                      <div className="flex items-center justify-between">
                        {/* اطلاعات آگهی - بهبود نمایش تصاویر */}
                        <div className="flex items-center flex-1">
                          <div className="relative mr-4">
                            {/* عکس اصلی با قابلیت کلیک برای گالری */}
                            <img
                              src={caseItem.image}
                              alt={caseItem.name}
                              className="w-24 h-24 rounded-2xl object-cover shadow-md cursor-pointer hover:shadow-lg transition-shadow"
                              onClick={() => openImageGallery(caseItem)}
                              onError={(e) => {
                                const target = e.target as HTMLImageElement;
                                target.src = `https://readdy.ai/api/search-image?query=Beautiful%20Persian%20woman%20portrait&width=150&height=150&seq=${caseItem.id}&orientation=portrait`;
                              }}
                            />
                            
                            {/* نشانگر گالری عکس */}
                            {caseItem.details?.gallery_images && caseItem.details.gallery_images.length > 1 && (
                              <div className="absolute -bottom-1 -right-1 bg-gradient-to-r from-purple-500 to-pink-500 text-white text-xs px-2 py-1 rounded-full font-bold shadow-lg">
                                <i className="ri-gallery-line ml-1"></i>
                                {caseItem.details.gallery_images.length}
                              </div>
                            )}
                            
                            {/* وضعیت آنلاین/آفلاین */}
                            <div
                              className={`absolute -top-1 -left-1 w-5 h-5 rounded-full border-2 border-white ${
                                caseItem.status === 'active'
                                  ? 'bg-green-500'
                                  : caseItem.status === 'reserved'
                                  ? 'bg-yellow-500'
                                  : 'bg-gray-500'
                              }`}
                            ></div>
                          </div>

                          <div className="flex-1">
                            <div className="flex items-center mb-2">
                              <h4 className="font-bold text-gray-800 text-base">{caseItem.name}</h4>
                              <div className="flex items-center mr-2 space-x-1 rtl:space-x-reverse">
                                {caseItem.verified && (
                                  <span className="bg-blue-100 text-blue-700 text-xs px-2 py-1 rounded-full">
                                    <i className="ri-verified-badge-line text-xs ml-1"></i>
                                    تایید
                                  </span>
                                )}
                                {caseItem.is_persistent && (
                                  <span className="bg-purple-100 text-purple-700 text-xs px-2 py-1 rounded-full">
                                    <i className="ri-bookmark-line text-xs ml-1"></i>
                                    دائمی
                                  </span>
                                )}
                              </div>
                            </div>

                            <div className="text-gray-600 text-sm space-y-1">
                              <div className="flex items-center">
                                <i className="ri-map-pin-line ml-1"></i>
                                <span>{caseItem.location}</span>
                                {caseItem.age && <span className="mr-2">• {caseItem.age} ساله</span>}
                                {caseItem.height && <span className="mr-2">• {caseItem.height}</span>}
                              </div>

                              {(caseItem.skin_color || caseItem.body_type) && (
                                <div className="flex items-center">
                                  <i className="ri-palette-line ml-1"></i>
                                  {caseItem.skin_color && <span>{caseItem.skin_color}</span>}
                                  {caseItem.body_type && <span className="mr-2">• {caseItem.body_type}</span>}
                                </div>
                              )}

                              {/* **نمایش صحیح نوع کیس در پنل ادمین** */}
                              <div className="flex items-center">
                                <i className="ri-vip-crown-line ml-1 text-purple-500"></i>
                                <span className="text-purple-600 font-medium">نوع کیس: {getCategoryName(caseItem.category)}</span>
                              </div>

                              {caseItem.experience_level && (
                                <div className="flex items-center">
                                  <i className="ri-star-line ml-1"></i>
                                  <span>{caseItem.experience_level}</span>
                                  {caseItem.price && (
                                    <span className="mr-2 text-green-600 font-semibold">
                                      • {caseItem.price.toLocaleString()} تومان
                                    </span>
                                  )}
                                </div>
                              )}
                            </div>

                            {/* ویژگی‌های شخصیتی */}
                            {caseItem.personality_traits && caseItem.personality_traits.length > 0 && (
                              <div className="flex flex-wrap gap-1 mt-2">
                                {caseItem.personality_traits.slice(0, 4).map((trait, index) => (
                                  <span
                                    key={index}
                                    className="bg-indigo-100 text-indigo-700 text-xs px-2 py-0.5 rounded-full"
                                  >
                                    {trait}
                                  </span>
                                ))}
                              </div>
                            )}

                            {/* تاریخ ایجاد */}
                            <div className="flex items-center justify-between mt-2">
                              {caseItem.created_at && (
                                <div className="flex items-center text-gray-500 text-xs">
                                  <i className="ri-calendar-line ml-1"></i>
                                  <span>{new Date(caseItem.created_at).toLocaleDateString('fa-IR')}</span>
                                </div>
                              )}
                              
                              <span className="text-xs text-gray-400 font-mono">#{caseItem.id}</span>
                            </div>
                          </div>
                        </div>

                        {/* عملیات - اضافه کردن دکمه مشاهده تصاویر */}
                        <div className="flex flex-col items-center space-y-3 mr-4">
                          {/* انتخابگر وضعیت */}
                          <select
                            value={caseItem.status}
                            onChange={(e) => updateCaseStatus(caseItem.id, e.target.value)}
                            className={`text-sm font-semibold px-4 py-2 rounded-xl border-0 focus:outline-none focus:ring-2 focus:ring-offset-1 cursor-pointer transition-all ${
                              caseItem.status === 'active'
                                ? 'bg-green-100 text-green-700 focus:ring-green-500'
                                : caseItem.status === 'reserved'
                                ? 'bg-yellow-100 text-yellow-700 focus:ring-yellow-500'
                                : 'bg-gray-100 text-gray-700 focus:ring-gray-500'
                            }`}
                          >
                            <option value="active">🟢 فعال</option>
                            <option value="reserved">🟡 رزرو</option>
                            <option value="deleted">🔴 حذف</option>
                          </select>

                          {/* دکمه مشاهده تصاویر */}
                          <button
                            onClick={() => openImageGallery(caseItem)}
                            className="bg-gradient-to-r from-purple-500 to-pink-600 hover:from-purple-600 hover:to-pink-700 text-white px-4 py-2 rounded-xl text-sm font-medium transition-all duration-300 shadow-lg whitespace-nowrap"
                          >
                            <i className="ri-gallery-line ml-1"></i>
                            مشاهده تصاویر
                          </button>

                          {/* **دکمه: تغییر مشخصات** */}
                          <button
                            onClick={() => openEditModal(caseItem)}
                            className="bg-gradient-to-r from-blue-500 to-indigo-600 hover:from-blue-600 hover:to-indigo-700 text-white px-4 py-2 rounded-xl text-sm font-medium transition-all duration-300 shadow-lg whitespace-nowrap"
                          >
                            <i className="ri-edit-2-line ml-1"></i>
                            تغییر مشخصات
                          </button>

                          {/* دکمه‌های سریع */}
                          <div className="flex space-x-2 rtl:space-x-reverse">
                            <button
                              onClick={() => navigate(`/case-details/${caseItem.id}`)}
                              className="w-8 h-8 bg-blue-100 hover:bg-blue-200 text-blue-600 rounded-lg flex items-center justify-center transition-colors"
                              title="مشاهده جزئیات"
                            >
                              <i className="ri-eye-line text-sm"></i>
                            </button>

                            <button
                              onClick={() => {
                                if (confirm(`آیا از حذف آگهی "${caseItem.name}" اطمینان دارید؟`)) {
                                  updateCaseStatus(caseItem.id, 'deleted');
                                }
                              }}
                              className="w-8 h-8 bg-red-100 hover:bg-red-200 text-red-600 rounded-lg flex items-center justify-center transition-colors"
                              title="حذف آگهی"
                            >
                              <i className="ri-delete-bin-line text-sm"></i>
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* صفحه‌بندی پایین */}
              {casesTotalPages > 1 && !casesLoading && (
                <div className="mt-6 border-t pt-4">
                  <div className="flex items-center justify-between">
                    <div className="text-sm text-gray-600">
                      نمایش {((casesCurrentPage - 1) * casesPerPage) + 1} تا{' '}
                      {Math.min(casesCurrentPage * casesPerPage, cases.length)} از {cases.length} آگهی
                    </div>

                    <div className="flex items-center space-x-2 rtl:space-x-reverse">
                      <button
                        onClick={prevCasesPage}
                        disabled={casesCurrentPage === 1}
                        className={`px-4 py-2 rounded-xl text-sm font-medium transition-all ${
                          casesCurrentPage === 1
                            ? 'bg-gray-100 text-gray-400 cursor-not-allowed'
                            : 'bg-gradient-to-r from-purple-500 to-indigo-600 hover:from-purple-600 hover:to-indigo-700 text-white shadow-lg'
                        }`}
                      >
                        <i className="ri-arrow-right-line ml-1"></i>
                        قبلی
                      </button>

                      <div className="bg-gradient-to-r from-purple-500 to-indigo-600 text-white px-4 py-2 rounded-xl text-sm font-medium">
                        {casesCurrentPage} / {casesTotalPages}
                      </div>

                      <button
                        onClick={nextCasesPage}
                        disabled={casesCurrentPage === casesTotalPages}
                        className={`px-4 py-2 rounded-xl text-sm font-medium transition-all ${
                          casesCurrentPage === casesTotalPages
                            ? 'bg-gray-100 text-gray-400 cursor-not-allowed'
                            : 'bg-gradient-to-r from-purple-500 to-indigo-600 hover:from-purple-600 hover:to-indigo-700 text-white shadow-lg'
                        }`}
                      >
                        بعدی
                        <i className="ri-arrow-left-line mr-1"></i>
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Image Upload Modal */}
      {showImageUploadModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-3xl w-full max-w-lg shadow-2xl max-h-[90vh] overflow-hidden">
            {/* Header */}
            <div className="bg-gradient-to-r from-blue-600 to-cyan-600 text-white p-6 rounded-t-3xl">
              <div className="flex items-center justify-between">
                <h3 className="text-xl font-bold flex items-center">
                  <i className="ri-image-add-line text-2xl ml-3"></i>
                  ثبت آگهی با عکس‌های متعدد
                </h3>
                <button
                  onClick={() => {
                    setShowImageUploadModal(false);
                    setUploadForm({ images: [], uploading: false });
                  }}
                  className="w-8 h-8 flex items-center justify-center rounded-full bg-white/20 hover:bg-white/30 transition-colors"
                >
                  <i className="ri-close-line text-lg"></i>
                </button>
              </div>
              <p className="text-blue-100 text-sm mt-2">
                تا 5 عکس آپلود کنید، بقیه مشخصات خودکار تولید می‌شود
              </p>
            </div>

            {/* Content */}
            <div className="p-6 overflow-y-auto max-h-[calc(90vh-140px)]">
              {uploadForm.images.length === 0 ? (
                <div>
                  <div className="border-2 border-dashed border-gray-300 rounded-2xl p-8 text-center hover:border-blue-400 transition-colors">
                    <input
                      type="file"
                      accept="image/*"
                      multiple
                      onChange={handleImageUpload}
                      className="hidden"
                      id="imageUpload"
                      disabled={uploadForm.uploading}
                    />
                    <label htmlFor="imageUpload" className="cursor-pointer">
                      <div className="space-y-3">
                        <div className="w-20 h-20 mx-auto bg-gradient-to-r from-blue-500 to-cyan-500 rounded-2xl flex items-center justify-center">
                          <i className="ri-upload-cloud-2-line text-white text-3xl"></i>
                        </div>
                        <div>
                          <p className="text-gray-700 font-semibold text-lg">عکس‌های کیس را آپلود کنید</p>
                          <p className="text-gray-500 text-sm mt-1">حداکثر 5 عکس - JPG, PNG تا 5MB هر کدام</p>
                        </div>
                      </div>
                    </label>
                  </div>
                  {uploadForm.uploading && (
                    <div className="mt-4 text-center">
                      <div className="inline-flex items-center">
                        <div className="w-5 h-5 border-2 border-blue-500 border-t-transparent rounded-full animate-spin ml-2"></div>
                        <span className="text-blue-600 text-sm">در حال آپلود عکس‌ها...</span>
                      </div>
                    </div>
                  )}
                </div>
              ) : (
                <div>
                  <div className="mb-6">
                    <h4 className="text-gray-800 font-semibold mb-3 flex items-center">
                      <i className="ri-gallery-line ml-2 text-blue-600"></i>
                      عکس‌های آپلود شده ({uploadForm.images.length}/5)
                    </h4>
                    <div className="grid grid-cols-2 gap-3 max-h-80 overflow-y-auto">
                      {uploadForm.images.map((image, index) => (
                        <div key={index} className="relative group">
                          <img
                            src={image}
                            alt={`عکس ${index + 1}`}
                            className="w-full h-32 object-cover rounded-xl shadow-lg"
                          />
                          <div className="absolute top-2 right-2">
                            <button
                              onClick={() => removeUploadedImage(index)}
                              className="w-6 h-6 bg-red-500 hover:bg-red-600 text-white rounded-full flex items-center justify-center text-xs transition-colors"
                            >
                              <i className="ri-close-line"></i>
                            </button>
                          </div>
                          <div className="absolute bottom-2 left-2 bg-black/70 text-white text-xs px-2 py-1 rounded-full">
                            {index === 0 ? 'اصلی' : `عکس ${index + 1}`}
                          </div>
                        </div>
                      ))}
                    </div>
                    {uploadForm.images.length < 5 && (
                      <div className="mt-3">
                        <input
                          type="file"
                          accept="image/*"
                          multiple
                          onChange={handleImageUpload}
                          className="hidden"
                          id="addMoreImages"
                        />
                        <label
                          htmlFor="addMoreImages"
                          className="inline-flex items-center bg-blue-100 hover:bg-blue-200 text-blue-700 px-4 py-2 rounded-xl text-sm cursor-pointer transition-colors"
                        >
                          <i className="ri-add-line ml-1"></i>
                          افزودن عکس بیشتر
                        </label>
                      </div>
                    )}
                  </div>

                  <div className="bg-gradient-to-r from-green-50 to-emerald-50 rounded-2xl p-4 mb-6">
                    <div className="text-center">
                      <i className="ri-check-line text-green-600 text-2xl mb-2"></i>
                      <p className="text-green-800 font-semibold">آماده برای تولید و ذخیره!</p>
                      <p className="text-green-600 text-sm mt-1">
                        تمام مشخصات خودکار تولید می‌شود + گالری {uploadForm.images.length} عکسه
                      </p>
                    </div>
                  </div>

                  <button
                    onClick={handleImageSubmit}
                    className="w-full bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-700 hover:to-cyan-700 text-white font-bold py-4 px-6 rounded-2xl shadow-lg transition-all duration-300"
                  >
                    <i className="ri-add-line ml-2 text-xl"></i>
                    ثبت آگهی با {uploadForm.images.length} عکس
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* **مودال جدید: گالری تصاویر** */}
      {showImageGallery && selectedCaseForGallery && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-3xl w-full max-w-4xl max-h-[90vh] overflow-hidden shadow-2xl">
            {/* Header */}
            <div className="bg-gradient-to-r from-purple-600 to-pink-600 text-white p-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <i className="ri-gallery-line text-2xl ml-3"></i>
                  <div>
                    <h3 className="text-xl font-bold">گالری تصاویر - {selectedCaseForGallery.name}</h3>
                    <p className="text-purple-100 text-sm mt-1">
                      آگهی #{selectedCaseForGallery.id} • {selectedCaseForGallery.location}
                    </p>
                  </div>
                </div>
                <button
                  onClick={closeImageGallery}
                  className="w-8 h-8 flex items-center justify-center rounded-full bg-white/20 hover:bg-white/30 transition-colors"
                >
                  <i className="ri-close-line text-lg"></i>
                </button>
              </div>
            </div>

            {/* Gallery Content */}
            <div className="p-6">
              {(() => {
                const galleryImages = selectedCaseForGallery.details?.gallery_images || [selectedCaseForGallery.image];
                return (
                  <div className="space-y-6">
                    {/* تصویر اصلی بزرگ */}
                    <div className="relative">
                      <img
                        src={galleryImages[galleryCurrentIndex]}
                        alt={`${selectedCaseForGallery.name} - تصویر ${galleryCurrentIndex + 1}`}
                        className="w-full h-96 object-cover rounded-2xl shadow-lg"
                        onError={(e) => {
                          const target = e.target as HTMLImageElement;
                          target.src = `https://readdy.ai/api/search-image?query=Beautiful%20Persian%20woman%20portrait&width=600&height=400&seq=${selectedCaseForGallery.id}_${galleryCurrentIndex}&orientation=portrait`;
                        }}
                      />
                      
                      {/* Navigation Arrows */}
                      {galleryImages.length > 1 && (
                        <>
                          <button
                            onClick={() => setGalleryCurrentIndex(galleryCurrentIndex > 0 ? galleryCurrentIndex - 1 : galleryImages.length - 1)}
                            className="absolute left-4 top-1/2 transform -translate-y-1/2 bg-black/50 hover:bg-black/70 text-white w-12 h-12 rounded-full flex items-center justify-center transition-all"
                          >
                            <i className="ri-arrow-left-line text-xl"></i>
                          </button>
                          <button
                            onClick={() => setGalleryCurrentIndex(galleryCurrentIndex < galleryImages.length - 1 ? galleryCurrentIndex + 1 : 0)}
                            className="absolute right-4 top-1/2 transform -translate-y-1/2 bg-black/50 hover:bg-black/70 text-white w-12 h-12 rounded-full flex items-center justify-center transition-all"
                          >
                            <i className="ri-arrow-right-line text-xl"></i>
                          </button>
                        </>
                      )}

                      {/* شماره تصویر فعلی */}
                      <div className="absolute bottom-4 left-4 bg-black/70 backdrop-blur text-white px-4 py-2 rounded-xl">
                        <div className="flex items-center text-sm">
                          <i className="ri-image-line ml-2"></i>
                          <span>{galleryCurrentIndex + 1} / {galleryImages.length}</span>
                        </div>
                      </div>
                    </div>

                    {/* تصاویر کوچک در پایین */}
                    {galleryImages.length > 1 && (
                      <div className="grid grid-cols-5 gap-3 max-h-32 overflow-y-auto">
                        {galleryImages.map((image, index) => (
                          <div
                            key={index}
                            className={`relative cursor-pointer transition-all duration-300 ${
                              index === galleryCurrentIndex
                                ? 'ring-4 ring-purple-500'
                                : 'hover:ring-2 hover:ring-gray-300'
                            }`}
                            onClick={() => setGalleryCurrentIndex(index)}
                          >
                            <img
                              src={image}
                              alt={`تصویر ${index + 1}`}
                              className="w-full h-20 object-cover rounded-xl shadow-md"
                              onError={(e) => {
                                const target = e.target as HTMLImageElement;
                                target.src = `https://readdy.ai/api/search-image?query=Beautiful%20Persian%20woman%20portrait&width=150&height=150&seq=${selectedCaseForGallery.id}_thumb_${index}&orientation=portrait`;
                              }}
                            />
                            {index === galleryCurrentIndex && (
                              <div className="absolute inset-0 bg-purple-500/20 rounded-xl flex items-center justify-center">
                                <i className="ri-check-line text-white text-xl"></i>
                              </div>
                            )}
                          </div>
                        ))}
                      </div>
                    )}

                    {/* اطلاعات تکمیلی */}
                    <div className="bg-gradient-to-r from-gray-50 to-white p-4 rounded-2xl">
                      <div className="grid grid-cols-2 gap-4 text-sm">
                        <div>
                          <span className="font-semibold text-gray-700">نام:</span>
                          <span className="mr-2 text-gray-600">{selectedCaseForGallery.name}</span>
                        </div>
                        <div>
                          <span className="font-semibold text-gray-700">استان:</span>
                          <span className="mr-2 text-gray-600">{selectedCaseForGallery.location}</span>
                        </div>
                        <div>
                          <span className="font-semibold text-gray-700">سن:</span>
                          <span className="mr-2 text-gray-600">{selectedCaseForGallery.age} ساله</span>
                        </div>
                        <div>
                          <span className="font-semibold text-gray-700">قد:</span>
                          <span className="mr-2 text-gray-600">{selectedCaseForGallery.height}</span>
                        </div>
                        <div>
                          <span className="font-semibold text-gray-700">تعداد نظرات:</span>
                          <span className="mr-2 text-gray-600">{selectedCaseForGallery.comments?.length || 0} نظر</span>
                        </div>
                        <div>
                          <span className="font-semibold text-gray-700">تعداد انتظارات:</span>
                          <span className="mr-2 text-gray-600">{selectedCaseForGallery.details?.expectations?.length || 0} انتظار</span>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })()}
            </div>
          </div>
        </div>
      )}

      {/* **مودال جدید: ویرایش مشخصات** */}
      {showEditModal && editingCase && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-3xl w-full max-w-lg shadow-2xl">
            {/* Header */}
            <div className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white p-6 rounded-t-3xl">
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <i className="ri-edit-2-line text-2xl ml-3"></i>
                  <div>
                    <h3 className="text-xl font-bold">ویرایش مشخصات آگهی</h3>
                    <p className="text-blue-100 text-sm mt-1">تغییرات برای همه کاربران اعمال می‌شود</p>
                  </div>
                </div>
                <button
                  onClick={closeEditModal}
                  className="w-8 h-8 flex items-center justify-center rounded-full bg-white/20 hover:bg-white/30 transition-colors"
                >
                  <i className="ri-close-line text-lg"></i>
                </button>
              </div>
            </div>

            {/* Content */}
            <div className="p-6">
              {/* نمایش عکس و شماره آگهی */}
              <div className="flex items-center mb-6 bg-gray-50 rounded-2xl p-4">
                <img
                  src={editingCase.image}
                  alt={editingCase.name}
                  className="w-16 h-16 rounded-2xl object-cover shadow-md mr-4"
                  onError={(e) => {
                    const target = e.target as HTMLImageElement;
                    target.src = `https://readdy.ai/api/search-image?query=Beautiful%20Persian%20woman%20portrait&width=100&height=100&seq=${editingCase.id}&orientation=portrait`;
                  }}
                />
                <div>
                  <div className="font-bold text-gray-800">آگهی شماره #{editingCase.id}</div>
                  <div className="text-gray-600 text-sm">تاریخ ایجاد: {editingCase.created_at ? new Date(editingCase.created_at).toLocaleDateString('fa-IR') : 'نامشخص'}</div>
                </div>
              </div>

              {/* فرم ویرایش */}
              <div className="space-y-6">
                {/* نام جدید */}
                <div>
                  <label className="block text-gray-700 font-semibold mb-3">نام جدید:</label>
                  <input
                    type="text"
                    value={editForm.name}
                    onChange={(e) => setEditForm(prev => ({ ...prev, name: e.target.value }))}
                    className="w-full bg-gray-50 border border-gray-200 rounded-2xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="نام جدید را وارد کنید"
                  />
                </div>

                {/* استان جدید */}
                <div>
                  <label className="block text-gray-700 font-semibold mb-3">استان جدید:</label>
                  <select
                    value={editForm.location}
                    onChange={(e) => setEditForm(prev => ({ ...prev, location: e.target.value }))}
                    className="w-full bg-gray-50 border border-gray-200 rounded-2xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent pr-8"
                  >
                    <option value="">استان را انتخاب کنید</option>
                    {IRANIAN_PROVINCES.map(province => (
                      <option key={province} value={province}>{province}</option>
                    ))}
                  </select>
                </div>

                {/* پیش‌نمایش تغییرات */}
                <div className="bg-gradient-to-r from-orange-50 to-amber-50 rounded-2xl p-4 border border-orange-200">
                  <div className="text-center">
                    <i className="ri-eye-line text-orange-600 text-xl mb-2"></i>
                    <div className="font-semibold text-orange-800 mb-2">پیش‌نمایش تغییرات:</div>
                    <div className="text-orange-700 text-sm">
                      <div>نام: <span className="font-medium">{editForm.name || 'نام جدید'}</span></div>
                      <div>استان: <span className="font-medium">{editForm.location || 'استان جدید'}</span></div>
                    </div>
                  </div>
                </div>

                {/* هشدار مهم */}
                <div className="bg-gradient-to-r from-red-50 to-pink-50 rounded-2xl p-4 border border-red-200">
                  <div className="flex items-start">
                    <i className="ri-alert-line text-red-600 text-xl ml-3 mt-1"></i>
                    <div>
                      <div className="font-semibold text-red-800 mb-1">⚠️ هشدار مهم:</div>
                      <div className="text-red-700 text-sm leading-relaxed">
                        این تغییرات در دیتابیس اصلی ذخیره شده و برای <strong>همه کاربران</strong> در تمام بخش‌ها (صفحه اصلی، جزئیات، چت) قابل مشاهده خواهد بود.
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* دکمه‌های عملیات */}
              <div className="flex space-x-4 rtl:space-x-reverse mt-8">
                <button
                  onClick={handleEditSubmit}
                  className="flex-1 bg-gradient-to-r from-green-600 to-emerald-700 hover:from-green-700 hover:to-emerald-800 text-white font-bold py-3 px-6 rounded-2xl shadow-lg transition-all duration-300"
                >
                  <i className="ri-save-line ml-2"></i>
                  ذخیره جهانی تغییرات
                </button>
                
                <button
                  onClick={closeEditModal}
                  className="flex-1 bg-gradient-to-r from-gray-500 to-gray-600 hover:from-gray-600 hover:to-gray-700 text-white font-bold py-3 px-6 rounded-2xl shadow-lg transition-all duration-300"
                >
                  <i className="ri-close-line ml-2"></i>
                  انصراف
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      <TabBar />
    </div>
  );
}
