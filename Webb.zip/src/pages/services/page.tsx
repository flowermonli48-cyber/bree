
import { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import NavBar from '../../components/base/NavBar';
import TabBar from '../../components/base/TabBar';
import { casesAPI, type CaseData } from '../../lib/supabase';

// استان‌های اصلی ایران
const iranProvinces = [
  'تهران', 'اصفهان', 'خراسان رضوی', 'خوزستان', 'فارس', 'آذربایجان شرقی',
  'مازندران', 'گیلان', 'کرمان', 'البرز', 'سیستان و بلوچستان', 'هرمزگان',
  'همدان', 'زنجان', 'یزد', 'اردبیل', 'لرستان', 'مرکزی', 'ایلام', 'بوشهر',
  'کردستان', 'آذربایجان غربی', 'قم', 'قزوین', 'گلستان', 'چهارمحال و بختیاری',
  'خراسان شمالی', 'خراسان جنوبی', 'کهگیلویه و بویراحمد', 'سمنان', 'کرمانشاه'
];

const ITEMS_PER_PAGE = 30; // 30 آگهی در هر صفحه

// **سیستم لودینگ جدید - حرفه‌ای و قدرتمند**
interface LoadingStats {
  totalCases: number;
  loadedCases: number;
  currentBatch: number;
  totalBatches: number;
  estimatedTimeRemaining: number;
  loadingSpeed: number; // آگهی در ثانیه
  startTime: number;
  phase: 'counting' | 'loading' | 'processing' | 'finalizing' | 'complete';
  message: string;
  tips: string[];
  currentTipIndex: number;
}

// **نکات مفید برای نمایش در حین بارگذاری**
const loadingTips = [
  "🔍 در حال بارگذاری آخرین لیست کیس‌های آنلاین فعال",
  "✅ تمامی کیس‌ها دارای تایید صحت سلامت معتبر هستند", 
  "💎 سیستم ما انواع روابط صیغه، شوگر و دوستی را ساپورت می‌کند",
  "🎁 ارتباط رایگان برای تمامی کیس‌ها برای شما فعال شده",
  "🔒 تمام اطلاعات کیس‌ها کاملاً محرمانه و امن نگهداری می‌شود",
  "⭐ کیس‌های تایید شده با بالاترین کیفیت خدمات در حال آماده‌سازی",
  "💬 چت امن و پشتیبانی 24 ساعته برای همه کیس‌ها فراهم است",
  "🌟 بهترین کیس‌های فعال برای انتخاب شما آماده می‌شوند"
];

export default function Services() {
  const navigate = useNavigate();
  const loadingIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const tipsIntervalRef = useRef<NodeJS.Timeout | null>(null);

  // States اصلی
  const [allCases, setAllCases] = useState<CaseData[]>([]); // تمام آگهی‌ها از دیتابیس
  const [filteredCases, setFilteredCases] = useState<CaseData[]>([]); // آگهی‌های فیلتر شده
  const [displayedCases, setDisplayedCases] = useState<CaseData[]>([]); // آگهی‌های نمایش داده شده در صفحه فعلی
  
  // States صفحه‌بندی
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(0);
  const [totalCasesCount, setTotalCasesCount] = useState(0);
  
  // **States جدید لودینگ پیشرفته**
  const [loading, setLoading] = useState(true);
  const [loadingStats, setLoadingStats] = useState<LoadingStats>({
    totalCases: 0,
    loadedCases: 0,
    currentBatch: 0,
    totalBatches: 0,
    estimatedTimeRemaining: 0,
    loadingSpeed: 0,
    startTime: Date.now(),
    phase: 'counting',
    message: '🔍 در حال شمارش آگهی‌ها از بانک داده...',
    tips: loadingTips,
    currentTipIndex: 0
  });
  
  const [pageLoading, setPageLoading] = useState(false);
  
  // States فیلتر و جستجو
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedProvince, setSelectedProvince] = useState('');
  const [sortBy, setSortBy] = useState('newest');
  const [showFilters, setShowFilters] = useState(false);
  const [showProvinceSearch, setShowProvinceSearch] = useState(false);
  const [provinceSearchTerm, setProvinceSearchTerm] = useState('');

  // **State جدید برای چت‌ها**
  const [chatRooms, setChatRooms] = useState<any[]>([]);

  // **محاسبه تایم و آمار هوشمند**
  const calculateLoadingStats = (totalCases: number, loadedCases: number, startTime: number) => {
    const elapsedTime = (Date.now() - startTime) / 1000; // ثانیه
    const loadingSpeed = loadedCases > 0 ? loadedCases / elapsedTime : 0;
    const remainingCases = totalCases - loadedCases;
    const estimatedTimeRemaining = loadingSpeed > 0 ? remainingCases / loadingSpeed : 0;
    
    return {
      loadingSpeed: Math.round(loadingSpeed),
      estimatedTimeRemaining: Math.max(0, Math.round(estimatedTimeRemaining))
    };
  };

  // فیلتر استان‌ها براساس جستجو
  const filteredProvinces = iranProvinces.filter(province =>
    province.toLowerCase().includes(provinceSearchTerm.toLowerCase())
  );

  // انتخاب استان
  const handleProvinceSelect = (province: string) => {
    setSelectedProvince(province);
    setShowProvinceSearch(false);
    setProvinceSearchTerm('');
  };

  // پاک کردن فیلتر استان
  const clearLocationFilter = () => {
    setSelectedProvince('');
  };

  // پاک کردن تمام فیلترها
  const clearAllFilters = () => {
    setSearchTerm('');
    setSelectedProvince('');
    setSortBy('newest');
  };

  // توابع صفحه‌بندی
  const nextPage = () => {
    if (currentPage < totalPages) {
      setPageLoading(true);
      setTimeout(() => {
        setCurrentPage(currentPage + 1);
        setPageLoading(false);
        window.scrollTo({ top: 0, behavior: 'smooth' });
      }, 300);
    }
  };

  const prevPage = () => {
    if (currentPage > 1) {
      setPageLoading(true);
      setTimeout(() => {
        setCurrentPage(currentPage - 1);
        setPageLoading(false);
        window.scrollTo({ top: 0, behavior: 'smooth' });
      }, 300);
    }
  };

  const goToPage = (page: number) => {
    if (page >= 1 && page <= totalPages && page !== currentPage) {
      setPageLoading(true);
      setTimeout(() => {
        setCurrentPage(page);
        setPageLoading(false);
        window.scrollTo({ top: 0, behavior: 'smooth' });
      }, 300);
    }
  };

  const jumpToFirstPage = () => goToPage(1);
  const jumpToLastPage = () => goToPage(totalPages);

  // فرمت قیمت
  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('fa-IR').format(price);
  };

  // نام دسته‌بندی - **اصلاح شده برای نمایش صحیح 100%**
  const getCategoryName = (category: string) => {
    const categories: { [key: string]: string } = {
      'temporary': 'صیغه موقت',
      'sighe': 'صیغه موقت', 
      'sugar': 'شوگر دیدی',
      'friendship': 'دوستی',
      'marriage': 'ازدواج موقت'
    };
    return categories[category] || 'صیغه موقت'; // پیش‌فرض صیغه
  };

  // شروع تایید هویت
  const startVerification = (caseId: string) => {
    navigate(`/verification?caseId=${caseId}`);
  };

  // افزودن به علاقه‌مندی‌ها
  const addToFavorites = async (caseItem: CaseData) => {
    try {
      await casesAPI.addToFavorites(caseItem.id);
      // نمایش پیام موفقیت
      showSuccessMessage(`${caseItem.name} به علاقه‌مندی‌ها اضافه شد`);
    } catch (error) {
      console.error('خطا در افزودن به علاقه‌مندی‌ها:', error);
      showErrorMessage('خطا در افزودن به علاقه‌مندی‌ها');
    }
  };

  // **سیستم لودینگ جدید - قدرتمند و مقیاس‌پذیر**
  useEffect(() => {
    loadAllCasesAdvanced();
    
    // پاکسازی intervals در cleanup
    return () => {
      if (loadingIntervalRef.current) {
        clearInterval(loadingIntervalRef.current);
      }
      if (tipsIntervalRef.current) {
        clearInterval(tipsIntervalRef.current);
      }
    };
  }, []);

  const loadAllCasesAdvanced = async () => {
    const startTime = Date.now();
    
    setLoading(true);
    setLoadingStats(prev => ({
      ...prev,
      startTime,
      phase: 'counting',
      message: '🔍 در حال شمارش آگهی‌ها از بانک داده...'
    }));

    // شروع انیمیشن tips
    startTipsAnimation();

    try {
      console.log('🚀 شروع بارگذاری پیشرفته آگهی‌ها...');

      // **مرحله 1: شمارش کل آگهی‌ها**
      await updateLoadingPhase('counting', '📊 در حال شمارش کل آگهی‌های بانک...');
      
      const stats = await casesAPI.getTotalStats();
      const totalCases = stats.activeCases;

      if (totalCases === 0) {
        console.warn('⚠️ هیچ آگهی فعالی یافت نشد');
        setLoadingStats(prev => ({ ...prev, message: '❌ هیچ آگهی فعالی در بانک یافت نشد' }));
        setAllCases([]);
        setTotalCasesCount(0);
        setLoading(false);
        return;
      }

      console.log(`📊 مجموع ${totalCases} آگهی فعال در بانک یافت شد`);

      // **مرحله 2: تنظیم پارامترهای بارگذاری**
      const optimalBatchSize = totalCases < 100 ? 20 : totalCases < 300 ? 30 : 50;
      const totalBatches = Math.ceil(totalCases / optimalBatchSize);
      
      setLoadingStats(prev => ({
        ...prev,
        totalCases,
        totalBatches,
        phase: 'loading',
        message: `⚡ شروع بارگذاری ${totalCases} آگهی در ${totalBatches} بخش...`
      }));

      // **مرحله 3: بارگذاری batch به batch**
      const allLoadedCases: CaseData[] = [];
      
      for (let batchIndex = 0; batchIndex < totalBatches; batchIndex++) {
        const batchStartTime = Date.now();
        
        // به‌روزرسانی وضعیت فعلی
        setLoadingStats(prev => {
          const stats = calculateLoadingStats(totalCases, allLoadedCases.length, startTime);
          return {
            ...prev,
            currentBatch: batchIndex + 1,
            loadedCases: allLoadedCases.length,
            phase: 'loading',
            message: `📥 بارگذاری بخش ${batchIndex + 1} از ${totalBatches}...`,
            ...stats
          };
        });

        try {
          const page = batchIndex + 1;
          const result = await casesAPI.getWithPagination(page, optimalBatchSize);
          
          if (result.cases && result.cases.length > 0) {
            allLoadedCases.push(...result.cases);
            console.log(`✅ بخش ${batchIndex + 1}: ${result.cases.length} آگهی بارگذاری شد (مجموع: ${allLoadedCases.length})`);
          }

          // شبیه‌سازی تأخیر کوتاه برای تجربه کاربری بهتر (فقط اگر batch ای سریع لود شد)
          const batchTime = Date.now() - batchStartTime;
          if (batchTime < 100) {
            await new Promise(resolve => setTimeout(resolve, 50));
          }

        } catch (batchError) {
          console.error(`❌ خطا در بارگذاری بخش ${batchIndex + 1}:`, batchError);
          
          // اگر خطا در batch ای رخ داد، ادامه بده
          setLoadingStats(prev => ({
            ...prev,
            message: `⚠️ خطا در بخش ${batchIndex + 1}, ادامه بارگذاری...`
          }));
          continue;
        }

        // به‌روزرسانی لحظه‌ای آمار
        const currentStats = calculateLoadingStats(totalCases, allLoadedCases.length, startTime);
        setLoadingStats(prev => ({
          ...prev,
          loadedCases: allLoadedCases.length,
          ...currentStats
        }));
      }

      // **مرحله 4: پردازش نهایی**
      await updateLoadingPhase('processing', '⚙️ در حال پردازش و تنظیم آگهی‌ها...');
      await new Promise(resolve => setTimeout(resolve, 500));

      // **مرحله 5: نهایی‌سازی**
      await updateLoadingPhase('finalizing', '✨ در حال نهایی‌سازی و آماده‌سازی نمایش...');
      await new Promise(resolve => setTimeout(resolve, 300));

      // **مرحله 6: تکمیل**
      setAllCases(allLoadedCases);
      setTotalCasesCount(allLoadedCases.length);
      
      setLoadingStats(prev => ({
        ...prev,
        phase: 'complete',
        loadedCases: allLoadedCases.length,
        message: `🎉 ${allLoadedCases.length} آگهی با موفقیت بارگذاری شد!`
      }));

      console.log(`🎉 بارگذاری کامل شد! ${allLoadedCases.length} آگهی از ${totalCases} درخواستی`);
      
      // نمایش پیام موفقیت
      showSuccessMessage(`🎉 ${allLoadedCases.length} آگهی با موفقیت بارگذاری شد!`);

    } catch (error) {
      console.error('❌ خطا در بارگذاری آگهی‌ها:', error);
      setLoadingStats(prev => ({
        ...prev,
        message: '❌ خطا در بارگذاری - لطفاً رفرش کنید',
        phase: 'counting'
      }));
      setAllCases([]);
      setTotalCasesCount(0);
      showErrorMessage('❌ خطا در بارگذاری آگهی‌ها - لطفاً صفحه را رفرش کنید');
    }
    
    // توقف انیمیشن tips
    stopTipsAnimation();
    
    // کمی تاخیر برای نمایش پیام نهایی
    setTimeout(() => {
      setLoading(false);
    }, 1000);
  };

  // **توابع کمکی لودینگ**
  const updateLoadingPhase = async (phase: LoadingStats['phase'], message: string) => {
    setLoadingStats(prev => ({ ...prev, phase, message }));
    await new Promise(resolve => setTimeout(resolve, 200));
  };

  const startTipsAnimation = () => {
    tipsIntervalRef.current = setInterval(() => {
      setLoadingStats(prev => ({
        ...prev,
        currentTipIndex: (prev.currentTipIndex + 1) % prev.tips.length
      }));
    }, 3000); // تغییر tip هر 3 ثانیه
  };

  const stopTipsAnimation = () => {
    if (tipsIntervalRef.current) {
      clearInterval(tipsIntervalRef.current);
      tipsIntervalRef.current = null;
    }
  };

  // **اضافه کردن توابع پیام نمایش**
  const showSuccessMessage = (message: string) => {
    const messageDiv = document.createElement('div');
    messageDiv.className = 'fixed top-20 left-4 right-4 bg-gradient-to-r from-green-500 to-emerald-600 text-white px-6 py-4 rounded-2xl shadow-xl z-50 text-center font-semibold animate-bounce';
    messageDiv.innerHTML = `
      <div class="flex items-center justify-center">
        <i class="ri-check-double-line text-xl ml-2"></i>
        <span>${message}</span>
      </div>
    `;
    document.body.appendChild(messageDiv);
    
    setTimeout(() => {
      if (document.body.contains(messageDiv)) {
        document.body.removeChild(messageDiv);
      }
    }, 4000);
  };

  const showErrorMessage = (message: string) => {
    const errorDiv = document.createElement('div');
    errorDiv.className = 'fixed top-20 left-4 right-4 bg-gradient-to-r from-red-500 to-pink-600 text-white px-6 py-4 rounded-2xl shadow-xl z-50 text-center font-semibold';
    errorDiv.innerHTML = `
      <div class="flex items-center justify-center">
        <i class="ri-error-warning-line text-xl ml-2"></i>
        <span>${message}</span>
      </div>
    `;
    document.body.appendChild(errorDiv);
    
    setTimeout(() => {
      if (document.body.contains(errorDiv)) {
        document.body.removeChild(errorDiv);
      }
    }, 5000);
  };

  // فیلتر و جستجو در تمام آگهی‌ها (نه فقط صفحه فعلی) - **اصلاح برای جلوگیری از تکرار**
  useEffect(() => {
    if (allCases.length === 0) return;

    console.log(`🔍 شروع فیلتر و جستجو در ${allCases.length} آگهی...`);

    // **حذف تکراری ها قبل از فیلتر**
    const uniqueAllCases = allCases.filter((item, index, self) => 
      index === self.findIndex(t => t.id === item.id)
    );

    if (uniqueAllCases.length !== allCases.length) {
      console.log(`🔧 ${allCases.length - uniqueAllCases.length} کیس تکراری در فیلتر حذف شد`);
      setAllCases(uniqueAllCases); // به‌روزرسانی state با کیس‌های منحصر به فرد
      return; // خروج تا useEffect دوباره اجرا شود
    }

    let filtered = [...uniqueAllCases]; // کپی از آگهی‌های منحصر به فرد

    // فیلتر جستجو - در تمام فیلدها
    if (searchTerm) {
      filtered = filtered.filter(caseItem => {
        const searchLower = searchTerm.toLowerCase();
        return (
          caseItem.name.toLowerCase().includes(searchLower) ||
          caseItem.description?.toLowerCase().includes(searchLower) ||
          caseItem.location.toLowerCase().includes(searchLower) ||
          caseItem.personality_traits?.some(trait => 
            trait.toLowerCase().includes(searchLower)
          ) ||
          caseItem.details?.interests?.some(interest => 
            interest.toLowerCase().includes(searchLower)
          ) ||
          (caseItem.age && caseItem.age.toString().includes(searchTerm)) ||
          (caseItem.height && caseItem.height.toLowerCase().includes(searchLower))
        );
      });
    }

    // فیلتر استان
    if (selectedProvince) {
      filtered = filtered.filter(caseItem => 
        caseItem.location === selectedProvince
      );
    }

    // مرتب‌سازی
    filtered = filtered.sort((a, b) => {
      switch (sortBy) {
        case 'newest':
          return new Date(b.created_at || 0).getTime() - new Date(a.created_at || 0).getTime();
        case 'oldest':
          return new Date(a.created_at || 0).getTime() - new Date(b.created_at || 0).getTime();
        case 'price-high':
          return (b.price || 0) - (a.price || 0);
        case 'price-low':
          return (a.price || 0) - (b.price || 0);
        case 'age-young':
          return (a.age || 25) - (b.age || 25);
        case 'age-old':
          return (b.age || 25) - (a.age || 25);
        default:
          return 0;
      }
    });

    setFilteredCases(filtered);
    
    // محاسبه صفحه‌بندی جدید
    const totalPagesNew = Math.ceil(filtered.length / ITEMS_PER_PAGE);
    setTotalPages(totalPagesNew);
    
    // اگر صفحه فعلی بیش از تعداد صفحات جدید است، به صفحه اول برو
    const newCurrentPage = currentPage > totalPagesNew ? 1 : currentPage;
    setCurrentPage(newCurrentPage);

    console.log(`📊 فیلتر کامل شد: ${filtered.length} آگهی منحصر به فرد، ${totalPagesNew} صفحه`);

  }, [allCases, searchTerm, selectedProvince, sortBy]);

  // محاسبه آگهی‌های صفحه فعلی - **اصلاح برای جلوگیری از تکرار**
  useEffect(() => {
    if (filteredCases.length === 0) {
      setDisplayedCases([]);
      return;
    }

    const startIndex = (currentPage - 1) * ITEMS_PER_PAGE;
    const endIndex = startIndex + ITEMS_PER_PAGE;
    const currentPageCases = filteredCases.slice(startIndex, endIndex);
    
    // **حذف تکراری ها در صفحه فعلی**
    const uniqueCurrentPageCases = currentPageCases.filter((item, index, self) => 
      index === self.findIndex(t => t.id === item.id)
    );

    if (uniqueCurrentPageCases.length !== currentPageCases.length) {
      console.log(`🔧 ${currentPageCases.length - uniqueCurrentPageCases.length} کیس تکراری در صفحه ${currentPage} حذف شد`);
    }
    
    setDisplayedCases(uniqueCurrentPageCases);

    console.log(`📄 صفحه ${currentPage}: نمایش ${uniqueCurrentPageCases.length} آگهی منحصر به فرد (از ${startIndex + 1} تا ${Math.min(endIndex, filteredCases.length)})`);

  }, [filteredCases, currentPage]);

  // بازنشانی صفحه به 1 هنگام تغییر فیلتر
  useEffect(() => {
    setCurrentPage(1);
  }, [searchTerm, selectedProvince, sortBy]);

  // **صفحه لودینگ جدید - فوق‌حرفه‌ای و جذاب**
  if (loading) {
    const progressPercentage = loadingStats.totalCases > 0 
      ? Math.round((loadingStats.loadedCases / loadingStats.totalCases) * 100)
      : 0;

    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 relative overflow-hidden">
        <NavBar title="آگهی‌ها" showBack={false} />

        {/* **پس‌زمینه انیمیشنی پیشرفته** */}
        <div className="fixed inset-0 overflow-hidden">
          {/* Gradient Orbs */}
          <div className="absolute -inset-10 opacity-30">
            <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-gradient-to-r from-pink-500 to-purple-600 rounded-full mix-blend-multiply filter blur-xl animate-blob"></div>
            <div className="absolute top-1/3 right-1/4 w-96 h-96 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-full mix-blend-multiply filter blur-xl animate-blob animation-delay-2000"></div>
            <div className="absolute bottom-1/4 left-1/3 w-96 h-96 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-full mix-blend-multiply filter blur-xl animate-blob animation-delay-4000"></div>
          </div>

          {/* Floating Particles */}
          <div className="absolute inset-0">
            {Array.from({ length: 50 }, (_, i) => (
              <div
                key={i}
                className="absolute w-2 h-2 bg-white rounded-full opacity-20 animate-float"
                style={{
                  left: `${Math.random() * 100}%`,
                  top: `${Math.random() * 100}%`,
                  animationDelay: `${Math.random() * 5}s`,
                  animationDuration: `${3 + Math.random() * 4}s`
                }}
              ></div>
            ))}
          </div>

          {/* Wave Animation */}
          <div className="absolute bottom-0 left-0 w-full h-32 opacity-20">
            <svg viewBox="0 0 1200 120" className="w-full h-full">
              <path
                d="M0,120L48,110C96,100,192,80,288,85.3C384,91,480,123,576,128C672,133,768,111,864,96C960,80,1056,72,1152,74.7C1248,77,1344,91,1392,98.7L1440,106.7V120H1392C1344,120,1248,120,1152,120C1056,120,960,120,864,120C768,120,672,120,576,120C480,120,384,120,288,120C192,120,96,120,48,120H0Z"
                fill="url(#wave-gradient)"
                className="animate-wave"
              />
              <defs>
                <linearGradient id="wave-gradient" x1="0%" y1="0%" x2="100%" y2="0%">
                  <stop offset="0%" stopColor="#8B5CF6" />
                  <stop offset="50%" stopColor="#06B6D4" />
                  <stop offset="100%" stopColor="#EC4899" />
                </linearGradient>
              </defs>
            </svg>
          </div>
        </div>

        <div className="relative pt-24 pb-20 px-4 flex items-center justify-center min-h-screen">
          <div className="bg-white/10 backdrop-blur-xl rounded-3xl p-8 shadow-2xl text-center max-w-lg w-full relative overflow-hidden border border-white/20">
            
            {/* **نوار پیشرفت حلقه‌ای پیشرفته** */}
            <div className="relative mb-8">
              <div className="w-32 h-32 mx-auto relative">
                {/* حلقه پس‌زمینه */}
                <svg className="w-32 h-32 transform -rotate-90" viewBox="0 0 120 120">
                  <circle
                    cx="60"
                    cy="60"
                    r="50"
                    fill="none"
                    stroke="rgba(255,255,255,0.1)"
                    strokeWidth="8"
                  />
                  <circle
                    cx="60"
                    cy="60"
                    r="50"
                    fill="none"
                    stroke="url(#progress-gradient)"
                    strokeWidth="8"
                    strokeLinecap="round"
                    strokeDasharray={`${2 * Math.PI * 50}`}
                    strokeDashoffset={`${2 * Math.PI * 50 * (1 - progressPercentage / 100)}`}
                    className="transition-all duration-500 ease-out drop-shadow-lg"
                  />
                  <defs>
                    <linearGradient id="progress-gradient" x1="0%" y1="0%" x2="100%" y2="0%">
                      <stop offset="0%" stopColor="#F59E0B" />
                      <stop offset="25%" stopColor="#EF4444" />
                      <stop offset="50%" stopColor="#8B5CF6" />
                      <stop offset="75%" stopColor="#06B6D4" />
                      <stop offset="100%" stopColor="#10B981" />
                    </linearGradient>
                  </defs>
                </svg>
                
                {/* آیکون مرکزی متحرک */}
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="w-16 h-16 bg-gradient-to-r from-pink-500 to-purple-600 rounded-full flex items-center justify-center shadow-xl animate-pulse">
                    <div className="text-2xl animate-bounce">
                      {loadingStats.phase === 'counting' ? '🔍' : 
                       loadingStats.phase === 'loading' ? '📥' : 
                       loadingStats.phase === 'processing' ? '⚙️' : 
                       loadingStats.phase === 'finalizing' ? '✨' : '🎉'}
                    </div>
                  </div>
                </div>

                {/* درصد در مرکز */}
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="mt-20 text-white font-bold text-lg">
                    {progressPercentage}%
                  </div>
                </div>
              </div>
            </div>

            {/* **عنوان و وضعیت فعلی** */}
            <h3 className="text-2xl font-bold text-white mb-3 animate-pulse">
              {loadingStats.phase === 'counting' && 'شمارش آگهی‌ها'}
              {loadingStats.phase === 'loading' && 'بارگذاری آگهی‌ها'}
              {loadingStats.phase === 'processing' && 'پردازش داده‌ها'}
              {loadingStats.phase === 'finalizing' && 'آماده‌سازی نمایش'}
              {loadingStats.phase === 'complete' && 'بارگذاری کامل شد!'}
            </h3>
            
            {/* **پیام وضعیت** */}
            <p className="text-white/80 text-lg mb-6 font-medium min-h-[28px] leading-relaxed">
              {loadingStats.message}
            </p>

            {/* **آمار تفصیلی با نمایش نمادین بانک** */}
            <div className="grid grid-cols-2 gap-4 mb-6">
              <div className="bg-white/10 rounded-2xl p-3 backdrop-blur-sm border border-white/20">
                <div className="text-2xl font-bold text-cyan-400">{loadingStats.loadedCases}</div>
                <div className="text-cyan-300 text-sm">کیس بارگذاری شده</div>
              </div>
              <div className="bg-white/10 rounded-2xl p-3 backdrop-blur-sm border border-white/20">
                <div className="text-2xl font-bold text-emerald-400">
                  {loadingStats.totalCases > 0 
                    ? `${Math.floor(loadingStats.totalCases / 100) * 100 + 37800}` 
                    : '37,800'
                  }
                </div>
                <div className="text-emerald-300 text-sm">کل بانک آگهی‌ها</div>
              </div>
              <div className="bg-white/10 rounded-2xl p-3 backdrop-blur-sm border border-white/20">
                <div className="text-2xl font-bold text-purple-400">{loadingStats.currentBatch}</div>
                <div className="text-purple-300 text-sm">بخش فعلی</div>
              </div>
              <div className="bg-white/10 rounded-2xl p-3 backdrop-blur-sm border border-white/20">
                <div className="text-2xl font-bold text-yellow-400">{loadingStats.estimatedTimeRemaining}s</div>
                <div className="text-yellow-300 text-sm">باقی‌مانده</div>
              </div>
            </div>

            {/* **Progress Bar خطی اضافی** */}
            <div className="relative mb-6">
              <div className="bg-white/20 rounded-full h-4 overflow-hidden backdrop-blur-sm border border-white/30">
                <div 
                  className="bg-gradient-to-r from-pink-500 via-purple-500 to-indigo-500 h-full transition-all duration-700 ease-out rounded-full relative overflow-hidden"
                  style={{ width: `${progressPercentage}%` }}
                >
                  <div className="absolute inset-0 bg-white/30 animate-shimmer"></div>
                  <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent animate-slide"></div>
                </div>
              </div>
              <div className="text-white/70 text-sm mt-2 font-medium">
                {loadingStats.loadingSpeed > 0 && (
                  <span>سرعت: {loadingStats.loadingSpeed} کیس/ثانیه • </span>
                )}
                {progressPercentage}% کامل شده
              </div>
            </div>

            {/* **نکات و اطلاعات کاربردی** */}
            <div className="bg-gradient-to-r from-white/5 to-white/10 rounded-2xl p-4 text-right backdrop-blur-sm border border-white/20">
              <div className="text-white/80 text-sm leading-relaxed">
                <div className="flex items-start mb-2">
                  <div className="w-5 h-5 bg-gradient-to-r from-cyan-500 to-blue-500 rounded-full flex items-center justify-center mr-2 mt-0.5 flex-shrink-0">
                    <i className="ri-lightbulb-line text-white text-xs"></i>
                  </div>
                  <div className="animate-fade-in">
                    {loadingStats.tips[loadingStats.currentTipIndex]}
                  </div>
                </div>
              </div>
              
              {/* **Progress dots for tips** */}
              <div className="flex justify-center mt-3 space-x-1 rtl:space-x-reverse">
                {loadingStats.tips.map((_, index) => (
                  <div
                    key={index}
                    className={`w-2 h-2 rounded-full transition-all duration-300 ${
                      index === loadingStats.currentTipIndex
                        ? 'bg-cyan-400 scale-125'
                        : 'bg-white/30'
                    }`}
                  ></div>
                ))}
              </div>
            </div>

            {/* **دکمه تلاش مجدد (فقط در صورت خطا)** */}
            {loadingStats.message.includes('خطا') && (
              <button
                onClick={() => window.location.reload()}
                className="mt-6 bg-gradient-to-r from-red-500 to-pink-600 hover:from-red-600 hover:to-pink-700 text-white px-6 py-3 rounded-2xl font-semibold transition-all duration-300 transform hover:scale-105 shadow-lg"
              >
                <i className="ri-refresh-line ml-2"></i>
                تلاش مجدد
              </button>
            )}

            {/* **پالس های انیمیشن در اطراف** */}
            <div className="absolute -top-4 -left-4 w-8 h-8 bg-pink-500/30 rounded-full animate-ping"></div>
            <div className="absolute -bottom-4 -right-4 w-6 h-6 bg-purple-500/30 rounded-full animate-ping animation-delay-2000"></div>
            <div className="absolute top-1/2 -right-4 w-4 h-4 bg-cyan-500/30 rounded-full animate-ping animation-delay-4000"></div>
          </div>
        </div>

        <TabBar />

        {/* **استایل‌های انیمیشن پیشرفته CSS** */}
        <style jsx>{`
          @keyframes blob {
            0%, 100% { transform: translate(0px, 0px) scale(1); }
            33% { transform: translate(30px, -50px) scale(1.1); }
            66% { transform: translate(-20px, 20px) scale(0.9); }
          }
          .animate-blob {
            animation: blob 7s infinite;
          }
          .animation-delay-2000 {
            animation-delay: 2s;
          }
          .animation-delay-4000 {
            animation-delay: 4s;
          }
          @keyframes shimmer {
            0% { transform: translateX(-100%); }
            100% { transform: translateX(100%); }
          }
          .animate-shimmer {
            animation: shimmer 2s infinite;
          }
          @keyframes slide {
            0% { transform: translateX(-200%); }
            100% { transform: translateX(200%); }
          }
          .animate-slide {
            animation: slide 3s infinite;
          }
          @keyframes float {
            0%, 100% { transform: translateY(0px) rotate(0deg); }
            50% { transform: translateY(-20px) rotate(180deg); }
          }
          .animate-float {
            animation: float var(--duration, 4s) ease-in-out infinite;
          }
          @keyframes wave {
            0% { transform: translateX(0); }
            50% { transform: translateX(-25%); }
            100% { transform: translateX(-50%); }
          }
          .animate-wave {
            animation: wave 4s ease-in-out infinite;
          }
          @keyframes fade-in {
            0% { opacity: 0; transform: translateY(10px); }
            100% { opacity: 1; transform: translateY(0); }
          }
          .animate-fade-in {
            animation: fade-in 0.5s ease-out;
          }
        `}</style>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 via-rose-50 to-purple-100">
      <NavBar title="آگهی‌ها" showBack={false} />

      <div className="pt-20 pb-20">
        {/* بخش جستجو و فیلترها */}
        <div className="px-4 mb-6">
          {/* نوار جستجوی پیشرفته */}
          <div className="relative mb-4">
            <input
              type="text"
              placeholder="جستجو در تمام آگهی‌ها (نام، توضیحات، استان، علایق، …)"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-white/95 backdrop-blur-sm border-none rounded-2xl px-5 py-4 pr-12 text-gray-700 placeholder-gray-400 shadow-lg focus:outline-none focus:ring-2 focus:ring-pink-500"
            />
            <i className="ri-search-line absolute right-4 top-1/2 transform -translate-y-1/2 text-gray-400 text-xl"></i>
            {searchTerm && (
              <button
                onClick={() => setSearchTerm('')}
                className="absolute left-4 top-1/2 transform -translate-y-1/2 w-6 h-6 bg-gray-200 hover:bg-gray-300 rounded-full flex items-center justify-center transition-colors"
              >
                <i className="ri-close-line text-gray-600 text-sm"></i>
              </button>
            )}
          </div>

          {/* **نتایج جستجو و آمار کامل با نمایش نمادین بانک بزرگ** */}
          <div className="bg-white/80 backdrop-blur-sm rounded-xl p-4 mb-4 text-center">
            <div className="flex items-center justify-center mb-2">
              <div className="w-2 h-2 bg-green-500 rounded-full mr-2 animate-pulse"></div>
              <p className="text-sm text-gray-600">
                {searchTerm || selectedProvince ? (
                  <>
                    <span className="font-bold text-blue-600">{filteredCases.length}</span> کیس یافت شد
                    {searchTerm && <span> برای "{searchTerm}"</span>}
                    {selectedProvince && <span> در {selectedProvince}</span>}
                    <span className="text-gray-500 mr-2">
                      • از بانک <span className="font-bold text-purple-600">37,800</span> کیسه
                    </span>
                  </>
                ) : (
                  <>
                    <span className="font-bold text-blue-600">{currentPage}</span> از <span className="font-bold text-gray-800">{Math.ceil(37800 / ITEMS_PER_PAGE).toLocaleString()}</span>
                    <span className="text-gray-500 mr-2">
                      • کل بانک: <span className="font-bold text-purple-600">37,800</span> کیس آنلاین
                    </span>
                  </>
                )}
              </p>
            </div>

            {/* نمایش اطلاعات صفحه‌بندی */}
            {totalPages > 1 && (
              <div className="text-xs text-gray-500 flex items-center justify-center">
                <i className="ri-pages-line mr-1"></i>
                <span>
                  صفحه {currentPage} از {totalPages} • 
                  نمایش {((currentPage - 1) * ITEMS_PER_PAGE) + 1} تا {Math.min(currentPage * ITEMS_PER_PAGE, filteredCases.length)} • 
                  هر صفحه {ITEMS_PER_PAGE} کیس
                </span>
              </div>
            )}

            {/* Progress Bar */}
            {totalPages > 1 && (
              <div className="mt-2 bg-gray-200 rounded-full h-1 overflow-hidden">
                <div
                  className="bg-gradient-to-r from-pink-500 to-purple-600 h-full transition-all duration-300"
                  style={{ width: `${(currentPage / totalPages) * 100}%` }}
                ></div>
              </div>
            )}
          </div>

          {/* دکمه انتخاب استان */}
          <button
            onClick={() => setShowProvinceSearch(true)}
            className="w-full bg-gradient-to-r from-blue-500 to-indigo-600 hover:from-blue-600 hover:to-indigo-700 text-white rounded-2xl px-4 py-4 shadow-lg flex items-center justify-center mb-4 transition-colors"
          >
            <i className="ri-map-pin-line text-white mr-2"></i>
            <span className="font-medium">
              {selectedProvince ? selectedProvince : 'انتخاب استان'}
            </span>
            <i className="ri-arrow-down-s-line text-white mr-2"></i>
          </button>

          {/* حذف فیلتر استان */}
          {selectedProvince && (
            <button
              onClick={clearLocationFilter}
              className="w-full bg-gray-500 hover:bg-gray-600 text-white rounded-xl px-4 py-2 mb-4 text-sm"
            >
              <i className="ri-close-line mr-1"></i>
              حذف فیلتر استان ({selectedProvince})
            </button>
          )}

          {/* دکمه فیلترهای پیشرفته */}
          <button
            onClick={() => setShowFilters(!showFilters)}
            className="bg-white/95 backdrop-blur-sm rounded-2xl px-4 py-3 shadow-lg flex items-center justify-center mb-4 hover:bg-white transition-colors w-full"
          >
            <i className="ri-filter-line text-gray-600 mr-2"></i>
            <span className="text-gray-700 font-medium">فیلترهای پیشرفته</span>
            <i className={`ri-arrow-${showFilters ? 'up' : 'down'}-s-line text-gray-600 mr-2 transition-transform`}></i>
          </button>

          {/* فیلترهای پیشرفته */}
          {showFilters && (
            <div className="bg-white/95 backdrop-blur-sm rounded-2xl p-4 shadow-lg mb-4 space-y-4">
              <div>
                <label className="block text-gray-700 font-medium mb-2">مرتب‌سازی براساس</label>
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value)}
                  className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 text-gray-700 focus:outline-none focus:ring-2 focus:ring-pink-500 pr-8"
                >
                  <option value="newest">جدیدترین</option>
                  <option value="oldest">قدیمی‌ترین</option>
                  <option value="price-high">گران‌ترین</option>
                  <option value="price-low">ارزان‌ترین</option>
                  <option value="age-young">جوان‌ترین</option>
                  <option value="age-old">مسن‌ترین</option>
                </select>
              </div>

              {/* دکمه پاک کردن تمام فیلترها */}
              {(searchTerm || selectedProvince || sortBy !== 'newest') && (
                <button
                  onClick={clearAllFilters}
                  className="w-full bg-gradient-to-r from-red-5to-pink-600 hover:from-red-600 hover:to-pink-700 text-white px-4 py-2 rounded-xl text-sm font-medium transition-colors"
                >
                  <i className="ri-refresh-line mr-2"></i>
                  پاک کردن تمام فیلترها
                </button>
              )}
            </div>
          )}
        </div>

        {/* خلاصه چت فعال */}
        <div className="px-4 mb-4">
          <div className="bg-gradient-to-r from-green-50 to-emerald-50 border border-green-200 rounded-2xl p-4">
            <div className="flex items-center justify-center">
              <i className="ri-database-2-line text-green-600 mr-2"></i>
              <span className="text-green-700 font-medium text-sm">
                💬 {chatRooms.length} چت فعال (همگام‌سازی شده)
              </span>
            </div>
          </div>
        </div>

        {/* نمایش آگهی‌ها */}
        <div className="px-3">
          {/* Loading صفحه */}
          {pageLoading && (
            <div className="text-center py-4 mb-4">
              <div className="inline-flex items-center bg-white/90 backdrop-blur-sm rounded-2xl px-6 py-3 shadow-lg">
                <div className="w-4 h-4 border-2 border-blue-500 border-t-transparent rounded-full animate-spin ml-2"></div>
                <span className="text-blue-600 font-medium">در حال بارگذاری صفحه {currentPage}...</span>
              </div>
            </div>
          )}

          {/* نمایش "کیسی یافت نشد" */}
          {displayedCases.length === 0 && !pageLoading ? (
            <div className="text-center py-12">
              <div className="w-24 h-24 mx-auto mb-6 bg-gray-100 rounded-full flex items-center justify-center">
                <i className="ri-search-line text-4xl text-gray-400"></i>
              </div>
              <h3 className="text-xl font-bold text-gray-800 mb-3">کیسی یافت نشد</h3>
              <p className="text-gray-600 leading-relaxed mb-4">
                {totalCasesCount === 0
                  ? 'در حال حاضر کیس فعال موجود نیست'
                  : filteredCases.length === 0
                  ? 'با فیلترهای انتخابی کیسی یافت نشد'
                  : 'در این صفحه کیسی وجود ندارد'}
              </p>
              
              {/* دکمه‌های عملیات */}
              <div className="flex flex-col space-y-3">
                {(searchTerm || selectedProvince) && (
                  <button
                    onClick={clearAllFilters}
                    className="bg-gradient-to-r from-blue-500 to-indigo-600 hover:from-blue-600 hover:to-indigo-700 text-white px-6 py-2 rounded-xl transition-colors"
                  >
                    <i className="ri-refresh-line mr-2"></i>
                    نمایش همه کیس‌ها
                  </button>
                )}
                
                <button
                  onClick={loadAllCasesAdvanced}
                  className="bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-white px-6 py-2 rounded-xl transition-colors"
                >
                  <i className="ri-download-cloud-line mr-2"></i>
                  بارگذاری مجدد کیس‌ها
                </button>
              </div>
            </div>
          ) : (
            /* گرید آگهی‌ها */
            <div className="grid grid-cols-1 gap-4">
              {displayedCases.map((caseItem) => (
                <div key={caseItem.id} className="bg-white/95 backdrop-blur-sm rounded-2xl shadow-lg hover:shadow-xl transition-all duration-30 overflow-hidden border border-white/30">
                  <div className="relative">
                    <img
                      src={caseItem.image}
                      alt={caseItem.name}
                      className="w-full h-48 object-cover object-top"
                      onError={(e) => {
                        const target = e.target as HTMLImageElement;
                        target.src = `https://readdy.ai/api/search-image?query=Beautiful%20Persian%20woman%20portrait%20elegant%20style&width=400&height=300&seq=${caseItem.id}&orientation=portrait`;
                      }}
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent"></div>

                    {/* Status Badges */}
                    <div className="absolute top-3 right-3 flex flex-col space-y-1">
                      {caseItem.online && (
                        <div className="bg-green-500/90 backdrop-blur-sm text-white text-xs font-bold px-2 py-1 rounded-full flex items-center shadow-lg">
                          <div className="w-2 h-2 bg-white rounded-full mr-1 animate-pulse"></div>
                          آنلاین
                        </div>
                      )}
                    </div>

                    {/* Price Tag */}
                    <div className="absolute top-3 left-3 bg-gradient-to-r from-green-500 to-emerald-600 text-white font-bold px-3 py-1.5 rounded-xl shadow-lg">
                      <div className="text-xs">
                        {formatPrice(caseItem.price)} تومان
                      </div>
                    </div>

                    {/* Name and Location */}
                    <div className="absolute bottom-3 left-3 right-3">
                      <h3 className="text-white text-lg font-bold mb-1 drop-shadow-lg">{caseItem.name}</h3>
                      <div className="flex items-center text-white/90 text-sm">
                        <i className="ri-map-pin-line mr-1"></i>
                        {caseItem.location}
                      </div>
                    </div>
                  </div>

                  {/* Card Content */}
                  <div className="p-4">
                    {/* ویژگی‌های شخصیتی */}
                    {caseItem.personality_traits && caseItem.personality_traits.length > 0 && (
                      <div className="mb-4">
                        <div className="flex flex-wrap gap-2">
                          {caseItem.personality_traits.slice(0, 3).map((trait: string, index: number) => (
                            <span
                              key={index}
                              className="bg-gradient-to-r from-pink-100 to-rose-100 text-pink-800 px-2 py-1 rounded-full text-xs font-medium shadow-sm border border-pink-200"
                            >
                              ✨ {trait}
                            </span>
                          ))}
                        </div>
                      </div>
                    )}

                    <div className="mb-4">
                      {/* نوع کیس - اصلاح شده */}
                      <div className="bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-200 rounded-xl p-3 mb-3">
                        <div className="flex items-center">
                          <i className="ri-vip-crown-line text-blue-600 mr-2"></i>
                          <span className="text-blue-800 font-semibold text-sm">
                            نوع کیس: {getCategoryName(caseItem.category)}
                          </span>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-2 text-xs text-gray-600">
                        {caseItem.age && (
                          <div className="flex items-center">
                            <i className="ri-user-line mr-1 text-purple-500"></i>
                            <span>{caseItem.age} ساله</span>
                          </div>
                        )}

                        {caseItem.height && (
                          <div className="flex items-center">
                            <i className="ri-ruler-line mr-1 text-green-500"></i>
                            <span>{caseItem.height}</span>
                          </div>
                        )}

                        {caseItem.skin_color && (
                          <div className="flex items-center">
                            <i className="ri-palette-line mr-1 text-orange-500"></i>
                            <span>{caseItem.skin_color}</span>
                          </div>
                        )}

                        {caseItem.body_type && (
                          <div className="flex items-center">
                            <i className="ri-body-scan-line mr-1 text-red-500"></i>
                            <span>{caseItem.body_type}</span>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* تایید صحت سلامت */}
                    <div className="mb-4 flex justify-center">
                      <div className="bg-green-100 text-green-800 px-3 py-2 rounded-full text-xs font-medium flex items-center">
                        <i className="ri-shield-check-fill mr-1"></i>
                        تایید صحت سلامت
                      </div>
                    </div>

                    <div className="space-y-2">
                      <button
                        onClick={() => navigate(`/case-details/${caseItem.id}`)}
                        className="w-full bg-gradient-to-r from-blue-500 to-indigo-600 hover:from-blue-600 hover:to-indigo-700 text-white text-sm font-bold px-4 py-3 rounded-xl transition-all duration-300 whitespace-nowrap"
                      >
                        <i className="ri-eye-line mr-2"></i>
                        مشاهده جزئیات
                      </button>

                      <div className="flex space-x-2 space-x-reverse">
                        <button
                          onClick={() => startVerification(caseItem.id)}
                          className="flex-1 bg-gradient-to-r from-pink-500 to-rose-600 hover:from-pink-600 hover:to-rose-700 text-white text-xs font-bold px-3 py-2 rounded-xl transition-all duration-300 whitespace-nowrap"
                        >
                          <i className="ri-chat-heart-line mr-1"></i>
                          چت
                        </button>
                        <button
                          onClick={() => addToFavorites(caseItem)}
                          className="flex-1 bg-gradient-to-r from-red-500 to-pink-600 hover:from-red-600 hover:to-pink-700 text-white text-xs font-bold px-3 py-2 rounded-xl transition-all duration-300 whitespace-nowrap"
                        >
                          <i className="ri-heart-add-line mr-1"></i>
                          علاقه‌مندی
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* صفحه‌بندی فوق حرفه‌ای */}
          {totalPages > 1 && !pageLoading && displayedCases.length > 0 && (
            <div className="mt-8 space-y-4">
              {/* اطلاعات صفحه */}
              <div className="bg-white/80 backdrop-blur-sm rounded-xl px-4 py-3 text-center">
                <p className="text-sm text-gray-600 mb-2">
                  صفحه <span className="font-bold text-blue-600">{currentPage}</span> از <span className="font-bold">{totalPages}</span>
                  <span className="mr-3">({displayedCases.length} آگهی در این صفحه)</span>
                </p>
                <div className="text-xs text-gray-500">
                  <span>نمایش {((currentPage - 1) * ITEMS_PER_PAGE) + 1} تا {Math.min(currentPage * ITEMS_PER_PAGE, filteredCases.length)} از {filteredCases.length} آگهی</span>
                  {filteredCases.length !== totalCasesCount && (
                    <span> (فیلتر شده از {totalCasesCount} آگهی کل)</span>
                  )}
                </div>
              </div>

              {/* دکمه‌های ناوبری */}
              <div className="flex items-center justify-center space-x-3 rtl:space-x-reverse">
                {/* اول */}
                <button
                  onClick={jumpToFirstPage}
                  disabled={currentPage === 1}
                  className={`px-3 py-2 rounded-xl font-medium transition-all ${
                    currentPage === 1
                      ? 'bg-gray-200 text-gray-400 cursor-not-allowed'
                      : 'bg-gradient-to-r from-blue-500 to-indigo-600 hover:from-blue-600 hover:to-indigo-700 text-white shadow-lg'
                  }`}
                >
                  <i className="ri-skip-back-line"></i>
                </button>

                {/* قبلی */}
                <button
                  onClick={prevPage}
                  disabled={currentPage === 1}
                  className={`px-4 py-2 rounded-xl font-medium transition-all ${
                    currentPage === 1
                      ? 'bg-gray-200 text-gray-400 cursor-not-allowed'
                      : 'bg-gradient-to-r from-blue-500 to-indigo-600 hover:from-blue-600 hover:to-indigo-700 text-white shadow-lg'
                  }`}
                >
                  <i className="ri-arrow-right-line ml-1"></i>
                  قبلی
                </button>

                {/* شماره صفحات */}
                <div className="flex space-x-1 rtl:space-x-reverse">
                  {/* صفحه اول */}
                  {currentPage > 3 && totalPages > 7 && (
                    <>
                      <button
                        onClick={() => goToPage(1)}
                        className="w-10 h-10 rounded-xl font-medium transition-all bg-white/80 text-gray-600 hover:bg-white hover:text-gray-800 hover:scale-105"
                      >
                        1
                      </button>
                      {currentPage > 4 && (
                        <span className="flex items-center text-gray-400 px-2">...</span>
                      )}
                    </>
                  )}

                  {/* محدوده صفحه فعلی */}
                  {Array.from({ length: Math.min(7, totalPages) }, (_, i) => {
                    let pageNum;
                    if (totalPages <= 7) {
                      pageNum = i + 1;
                    } else if (currentPage <= 4) {
                      pageNum = i + 1;
                    } else if (currentPage >= totalPages - 3) {
                      pageNum = totalPages - 6 + i;
                    } else {
                      pageNum = currentPage - 3 + i;
                    }

                    // اگر قبلاً نمایش داده شده، رد کن
                    if ((currentPage > 3 && totalPages > 7) && (pageNum === 1)) {
                      return null;
                    }

                    return (
                      <button
                        key={pageNum}
                        onClick={() => goToPage(pageNum)}
                        className={`w-10 h-10 rounded-xl font-medium transition-all ${
                          currentPage === pageNum
                            ? 'bg-gradient-to-r from-pink-500 to-rose-600 text-white shadow-lg scale-110'
                            : 'bg-white/80 text-gray-600 hover:bg-white hover:text-gray-800 hover:scale-105'
                        }`}
                      >
                        {pageNum}
                      </button>
                    );
                  })}

                  {/* صفحه آخر */}
                  {currentPage < totalPages - 3 && totalPages > 7 && (
                    <>
                      {currentPage < totalPages - 4 && (
                        <span className="flex items-center text-gray-400 px-2">...</span>
                      )}
                      <button
                        onClick={() => goToPage(totalPages)}
                        className="w-10 h-10 rounded-xl font-medium transition-all bg-white/80 text-gray-600 hover:bg-white hover:text-gray-800 hover:scale-105"
                      >
                        {totalPages}
                      </button>
                    </>
                  )}
                </div>

                {/* بعدی */}
                <button
                  onClick={nextPage}
                  disabled={currentPage === totalPages}
                  className={`px-4 py-2 rounded-xl font-medium transition-all ${
                    currentPage === totalPages
                      ? 'bg-gray-200 text-gray-400 cursor-not-allowed'
                      : 'bg-gradient-to-r from-blue-500 to-indigo-600 hover:from-blue-600 hover:to-indigo-700 text-white shadow-lg'
                  }`}
                >
                  بعدی
                  <i className="ri-arrow-left-line mr-1"></i>
                </button>

                {/* آخر */}
                <button
                  onClick={jumpToLastPage}
                  disabled={currentPage === totalPages}
                  className={`px-3 py-2 rounded-xl font-medium transition-all ${
                    currentPage === totalPages
                      ? 'bg-gray-200 text-gray-400 cursor-not-allowed'
                      : 'bg-gradient-to-r from-blue-500 to-indigo-600 hover:from-blue-600 hover:to-indigo-700 text-white shadow-lg'
                  }`}
                >
                  <i className="ri-skip-forward-line"></i>
                </button>
              </div>

              {/* Progress Bar کلی */}
              <div className="bg-white/60 rounded-full h-2 overflow-hidden">
                <div
                  className="bg-gradient-to-r from-pink-500 to-rose-600 h-full transition-all duration-300"
                  style={{ width: `${(currentPage / totalPages) * 100}%` }}
                ></div>
              </div>

              {/* پرش سریع */}
              {totalPages > 15 && (
                <div className="text-center">
                  <details className="bg-white/80 backdrop-blur-sm rounded-xl p-4 shadow-lg">
                    <summary className="cursor-pointer text-gray-700 font-medium">
                      <i className="ri-skip-forward-line mr-2"></i>
                      پرش سریع به صفحه خاص
                    </summary>
                    <div className="mt-3 flex items-center justify-center space-x-3 rtl:space-x-reverse">
                      <span className="text-gray-600 text-sm">صفحه:</span>
                      <input
                        type="number"
                        min="1"
                        max={totalPages}
                        placeholder={currentPage.toString()}
                        className="w-20 px-2 py-1 border border-gray-300 rounded-lg text-center text-sm focus:outline-none focus:ring-2 focus:ring-pink-500"
                        onKeyPress={(e) => {
                          if (e.key === 'Enter') {
                            const target = e.target as HTMLInputElement;
                            const page = parseInt(target.value);
                            if (page >= 1 && page <= totalPages) {
                              goToPage(page);
                              target.value = '';
                            }
                          }
                        }}
                      />
                      <span className="text-gray-500 text-sm">از {totalPages}</span>
                    </div>
                  </details>
                </div>
              )}

              {/* نکات کاربردی */}
              <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-xl p-4 text-center">
                <p className="text-blue-800 text-sm font-medium mb-2">
                  💡 نکات مفید برای جستجو
                </p>
                <div className="text-blue-700 text-xs space-y-1">
                  <p>• جستجو در تمام {totalCasesCount} کیس انجام می‌شود، نه فقط صفحه فعلی</p>
                  <p>• می‌توانید بر اساس نام، استان، علایق و ویژگی‌ها جستجو کنید</p>
                  <p>• فیلترهای مختلف را ترکیب کنید تا نتیجه بهتری دریافت کنید</p>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Province Search Modal */}
      {showProvinceSearch && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl w-full max-w-md max-h-96 overflow-hidden shadow-2xl">
            <div className="bg-gradient-to-r from-blue-500 to-indigo-600 text-white p-4 flex items-center justify-between">
              <h3 className="font-bold text-lg">انتخاب استان</h3>
              <button
                onClick={() => setShowProvinceSearch(false)}
                className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center"
              >
                <i className="ri-close-line"></i>
              </button>
            </div>

            {/* Search Input */}
            <div className="p-4 border-b border-gray-200">
              <input
                type="text"
                placeholder="جستجو در استان‌ها..."
                value={provinceSearchTerm}
                onChange={(e) => setProvinceSearchTerm(e.target.value)}
                className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div className="p-4 max-h-64 overflow-y-auto">
              <div className="grid grid-cols-1 gap-2">
                {filteredProvinces.map((province) => (
                  <button
                    key={province}
                    onClick={() => handleProvinceSelect(province)}
                    className="text-right bg-gray-50 hover:bg-blue-50 text-gray-700 hover:text-blue-700 px-4 py-3 rounded-xl text-sm transition-colors flex items-center"
                  >
                    <i className="ri-map-pin-line ml-2 text-blue-500"></i>
                    {province}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* پیام زمانی که چت‌ها موجود نیستند */}
      {chatRooms.length === 0 && (
        <div className="text-center py-12">
          <h3 className="text-lg font-semibold text-gray-700 mb-2">هیچ چتی یافت نشد</h3>
          <p className="text-gray-500 text-sm mb-6">
            برای شروع چت، ابتدا کیس‌های مورد نظر خود را به علاقه‌مندی‌ها اضافه کنید
          </p>
          <button
            onClick={() => navigate('/services')}
            className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-semibold py-3 px-6 rounded-2xl transition-all duration-300"
          >
            مشاهده کیس‌ها
          </button>
        </div>
      )}

      <TabBar />
    </div>
  );
}
