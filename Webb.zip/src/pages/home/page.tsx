
import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import NavBar from '../../components/base/NavBar';
import TabBar from '../../components/base/TabBar';
import { casesAPI, type CaseData } from '../../lib/supabase';

// نوع داده برای progress
interface LoadingProgress {
  phase: 'counting' | 'loading' | 'processing' | 'finalizing';
  currentBatch: number;
  totalBatches: number;
  loadedCount: number;
  totalCount: number;
  speed: number;
  timeRemaining: number;
  percentage: number;
}

export default function Home() {
  const navigate = useNavigate();
  const [uniqueCodeInput, setUniqueCodeInput] = useState('');
  const [cases, setCases] = useState<CaseData[]>([]);
  const [loading, setLoading] = useState(false);  // تغییر: شروع با false
  const [loadingProgress, setLoadingProgress] = useState<LoadingProgress | null>(null);
  const [showAdvancedLoading, setShowAdvancedLoading] = useState(false);

  useEffect(() => {
    // بارگذاری خودکار در شروع حذف شد - فقط وقتی کاربر بخواه
  }, []);

  // **تابع لودینگ پیشرفته با صفحه فوق‌حرفه‌ای**
  const loadRecentCasesAdvanced = async () => {
    setLoading(true);
    setShowAdvancedLoading(true);
    setLoadingProgress(null);
    
    try {
      console.log('🚀 شروع بارگذاری پیشرفته آگهی‌ها...');
      
      // بارگذاری آگهی‌های فعال با callback پیشرفت
      const activeCases = await casesAPI.getAll((progress) => {
        setLoadingProgress(progress);
        console.log(`📊 پیشرفت: ${progress.phase} - ${progress.percentage}% - ${progress.loadedCount}/${progress.totalCount}`);
      });
      
      const activeOnly = activeCases.filter(c => c.status === 'active');
      setCases(activeOnly);
      
      console.log(`✅ بارگذاری کامل شد: ${activeOnly.length} آگهی فعال`);
      
      // تاخیر برای نمایش کامل شدن
      await new Promise(resolve => setTimeout(resolve, 1000));
      
    } catch (error) {
      console.error('خطا در بارگذاری آگهی‌ها:', error);
      setCases([]);
    } finally {
      setLoading(false);
      setShowAdvancedLoading(false);
      setLoadingProgress(null);
    }
  };

  const startChatFromHome = () => {
    if (!uniqueCodeInput.trim()) {
      alert('لطفاً کد یکتا را وارد کنید');
      return;
    }
    
    navigate('/chat', { state: { uniqueCode: uniqueCodeInput } });
  };

  const totalCases = cases.length;

  // **نکات مفید برای نمایش در حین بارگذاری**
  const loadingTips = [
    "🔍 در حال بارگذاری آخرین لیست کیس‌های آنلاین فعال",
    "✅ تمامی کیس‌ها دارای تایید صحت سلامت معتبر هستند",
    "💎 سیستم ما انواع روابط صیغه، شوگر و دوستی را ساپورت می‌کند",
    "🎁 ارتباط رایگان برای تمامی کیس‌ها برای شما فعال شده",
    "🔒 تمام اطلاعات کیس‌ها کاملاً محرمانه و امن نگهداری می‌شود",
    "⭐ کیس‌های تایید شده با بالاترین کیفیت خدمات",
    "💬 چت امن و پشتیبانی 24 ساعته برای همه کیس‌ها",
    "🌟 بهترین کیس‌های فعال برای انتخاب شما آماده می‌شوند"
  ];

  const [currentTipIndex, setCurrentTipIndex] = useState(0);

  useEffect(() => {
    if (showAdvancedLoading) {
      const interval = setInterval(() => {
        setCurrentTipIndex((prev) => (prev + 1) % loadingTips.length);
      }, 3000);
      return () => clearInterval(interval);
    }
  }, [showAdvancedLoading]);

  // **رندر صفحه لودینگ فوق‌حرفه‌ای**
  if (showAdvancedLoading) {
    const progress = loadingProgress;
    
    return (
      <div className="min-h-screen bg-gradient-to-br from-indigo-900 via-purple-900 to-pink-900 flex items-center justify-center overflow-hidden relative">
        {/* انیمیشن پس‌زمینه */}
        <div className="absolute inset-0">
          {/* Animated Blobs */}
          <div className="absolute top-1/4 left-1/4 w-72 h-72 bg-gradient-to-r from-purple-500/30 to-pink-500/30 rounded-full mix-blend-multiply filter blur-xl animate-blob opacity-70"></div>
          <div className="absolute top-1/3 right-1/4 w-72 h-72 bg-gradient-to-r from-blue-500/30 to-indigo-500/30 rounded-full mix-blend-multiply filter blur-xl animate-blob animation-delay-2000 opacity-70"></div>
          <div className="absolute bottom-1/4 left-1/3 w-72 h-72 bg-gradient-to-r from-green-500/30 to-cyan-500/30 rounded-full mix-blend-multiply filter blur-xl animate-blob animation-delay-4000 opacity-70"></div>
          
          {/* Floating Particles */}
          {Array.from({ length: 20 }, (_, i) => (
            <div
              key={i}
              className="absolute w-2 h-2 bg-white/20 rounded-full animate-pulse"
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
                animationDelay: `${Math.random() * 3}s`,
                animationDuration: `${2 + Math.random() * 2}s`
              }}
            ></div>
          ))}
          
          {/* Wave Animation */}
          <div className="absolute bottom-0 left-0 w-full">
            <svg className="w-full h-24" viewBox="0 0 1200 120" preserveAspectRatio="none">
              <path 
                d="M0,0V46.29c47.79,22.2,103.59,32.17,158,28,70.36-5.37,136.33-33.31,206.8-37.5C438.64,32.43,512.34,53.67,583,72.05c69.27,18,138.3,24.88,209.4,13.08,36.15-6,69.85-17.84,104.45-29.34C989.49,25,1113-14.29,1200,52.47V0Z" 
                fill="rgba(255,255,255,0.1)"
                className="animate-pulse"
              />
            </svg>
          </div>
        </div>

        {/* محتوای اصلی لودینگ */}
        <div className="relative z-10 text-center px-6 max-w-lg mx-auto">
          {/* لوگو و عنوان */}
          <div className="mb-8">
            <div className="w-24 h-24 bg-gradient-to-r from-pink-500 to-purple-600 rounded-3xl flex items-center justify-center mx-auto mb-6 shadow-2xl animate-pulse">
              <i className="ri-heart-3-fill text-white text-4xl"></i>
            </div>
            <h1 className="text-4xl font-bold text-white mb-2 font-pacifico">
              کیس یاب
            </h1>
            <p className="text-white/80 text-lg">در حال بارگذاری آگهی‌ها...</p>
          </div>

          {/* Progress Circle */}
          <div className="relative w-32 h-32 mx-auto mb-8">
            <svg className="w-32 h-32 transform -rotate-90" viewBox="0 0 120 120">
              {/* Background Circle */}
              <circle
                cx="60"
                cy="60"
                r="50"
                stroke="rgba(255,255,255,0.2)"
                strokeWidth="8"
                fill="none"
              />
              {/* Progress Circle */}
              <circle
                cx="60"
                cy="60"
                r="50"
                stroke="url(#gradient)"
                strokeWidth="8"
                fill="none"
                strokeLinecap="round"
                strokeDasharray={314}
                strokeDashoffset={314 - (314 * (progress?.percentage || 0)) / 100}
                className="transition-all duration-500 ease-out drop-shadow-lg"
              />
              <defs>
                <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="0%">
                  <stop offset="0%" stopColor="#ec4899" />
                  <stop offset="50%" stopColor="#8b5cf6" />
                  <stop offset="100%" stopColor="#06b6d4" />
                </linearGradient>
              </defs>
            </svg>
            
            {/* درصد وسط */}
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="text-center">
                <div className="text-3xl font-bold text-white">{progress?.percentage || 0}%</div>
                <div className="text-white/60 text-xs">پیشرفت</div>
              </div>
            </div>
          </div>

          {/* اطلاعات تفصیلی پیشرفت */}
          {progress && (
            <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-6 mb-6 border border-white/20">
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div className="text-center">
                  <div className="text-white/60 mb-1">فاز فعلی</div>
                  <div className="text-white font-semibold">
                    {progress.phase === 'counting' && '🌐 در حال شمارش...'}
                    {progress.phase === 'loading' && '📊 در حال بارگذاری...'}
                    {progress.phase === 'processing' && '⚙️ در حال پردازش...'}
                    {progress.phase === 'finalizing' && '✅ نهایی‌سازی...'}
                  </div>
                </div>
                <div className="text-center">
                  <div className="text-white/60 mb-1">آگهی‌ها</div>
                  <div className="text-white font-semibold">
                    {progress.loadedCount.toLocaleString()} / {progress.totalCount.toLocaleString()}
                  </div>
                </div>
                {progress.totalBatches > 0 && (
                  <div className="text-center">
                    <div className="text-white/60 mb-1">Batch ها</div>
                    <div className="text-white font-semibold">
                      {progress.currentBatch} / {progress.totalBatches}
                    </div>
                  </div>
                )}
                {progress.speed > 0 && (
                  <div className="text-center">
                    <div className="text-white/60 mb-1">سرعت</div>
                    <div className="text-white font-semibold">
                      {progress.speed} آگهی/ثانیه
                    </div>
                  </div>
                )}
              </div>
              
              {progress.timeRemaining > 0 && (
                <div className="mt-4 text-center">
                  <div className="text-white/60 text-sm">زمان باقی‌مانده تخمینی</div>
                  <div className="text-white font-bold text-lg">
                    {progress.timeRemaining < 60 
                      ? `${Math.round(progress.timeRemaining)} ثانیه`
                      : `${Math.round(progress.timeRemaining / 60)} دقیقه`
                    }
                  </div>
                </div>
              )}
            </div>
          )}

          {/* نکات مفید چرخشی */}
          <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-4 border border-white/20">
            <div className="flex items-center justify-center min-h-[60px]">
              <div className="text-center">
                <div className="text-white/80 text-sm leading-relaxed animate-fade-in">
                  {loadingTips[currentTipIndex]}
                </div>
              </div>
            </div>
            
            {/* نقاط نشان‌دهنده */}
            <div className="flex justify-center mt-3 space-x-1 space-x-reverse">
              {loadingTips.map((_, index) => (
                <div
                  key={index}
                  className={`w-2 h-2 rounded-full transition-all duration-300 ${
                    index === currentTipIndex ? 'bg-white' : 'bg-white/30'
                  }`}
                ></div>
              ))}
            </div>
          </div>

          {/* Spinner اضافی */}
          <div className="mt-6">
            <div className="w-8 h-8 border-2 border-white/30 border-t-white rounded-full animate-spin mx-auto"></div>
          </div>
        </div>

        {/* استایل‌های CSS اضافی */}
        <style jsx>{`
          @keyframes blob {
            0% { transform: translate(0px, 0px) scale(1); }
            33% { transform: translate(30px, -50px) scale(1.1); }
            66% { transform: translate(-20px, 20px) scale(0.9); }
            100% { transform: translate(0px, 0px) scale(1); }
          }
          
          .animate-blob {
            animation: blob 7s infinite;
          }
          
          .animation-delay-2000 {
            animation-delay: 2s;
          }
          
          .animation-delay-4000 {
            animation-delay: 4s;
          }
          
          @keyframes fade-in {
            0% { opacity: 0; transform: translateY(10px); }
            100% { opacity: 1; transform: translateY(0); }
          }
          
          .animate-fade-in {
            animation: fade-in 0.5s ease-out;
          }
        `}</style>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 via-rose-50 to-purple-100">
      <NavBar title="کیس یاب" showBack={false} />

      <div className="pt-20 pb-20 px-4">
        {/* Hero Section */}
        <div className="pt-6 pb-8 px-6 text-center">
          <div className="mb-6">
            <h1 className="text-4xl font-bold mb-2 font-pacifico">
              <span className="bg-gradient-to-r from-pink-600 to-purple-600 bg-clip-text text-transparent">
                کیس یاب
              </span>
            </h1>
            <p className="text-gray-600 text-lg">بزرگترین پلتفرم کیس‌یابی ایران</p>
          </div>

          {/* Hero Image */}
          <div className="mb-8 relative">
            <div className="w-full h-48 rounded-3xl overflow-hidden shadow-2xl bg-gradient-to-r from-pink-500 to-purple-600 flex items-center justify-center">
              <img 
                src="https://readdy.ai/api/search-image?query=Elegant%20dating%20app%20interface%2C%20modern%20romantic%20design%2C%20couple%20silhouettes%2C%20heart%20shapes%2C%20gradient%20pink%20purple%20background%2C%20mobile%20app%20mockup%2C%20love%20connection%20illustration%2C%20Persian%20romantic%20theme&width=350&height=200&seq=hero2&orientation=landscape"
                alt="پلتفرم کیس یاب"
                className="w-full h-full object-cover"
              />
            </div>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-3 gap-4 mb-8">
            <div className="bg-white/80 backdrop-blur-sm rounded-2xl p-4 shadow-lg">
              <div className="text-2xl font-bold text-gray-800">500K+</div>
              <div className="text-sm text-gray-600">کاربر فعال</div>
            </div>
            <div className="bg-white/80 backdrop-blur-sm rounded-2xl p-4 shadow-lg">
              <div className="text-2xl font-bold text-gray-800">95%</div>
              <div className="text-sm text-gray-600">موفقیت ملاقات</div>
            </div>
            <div className="bg-white/80 backdrop-blur-sm rounded-2xl p-4 shadow-lg">
              <div className="text-2xl font-bold text-gray-800">24/7</div>
              <div className="text-sm text-gray-600">پشتیبانی آنلاین</div>
            </div>
          </div>
        </div>

        {/* Features Grid */}
        <div className="px-6 mb-8">
          <h2 className="text-2xl font-bold text-gray-800 mb-6 text-center">خدمات ویژه</h2>
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-white/90 backdrop-blur-sm rounded-3xl p-6 shadow-xl hover:shadow-2xl transition-all duration-300 hover:scale-105">
              <div className="w-16 h-16 rounded-2xl bg-gradient-to-r from-pink-500 to-pink-600 flex items-center justify-center mb-4 mx-auto shadow-lg">
                <i className="ri-heart-fill text-white text-2xl"></i>
              </div>
              <h3 className="font-bold text-gray-800 mb-2 text-center">صیغه موقت</h3>
              <p className="text-sm text-gray-600 text-center leading-relaxed">آشنایی با افراد برای صیغه موقت</p>
            </div>
            
            <div className="bg-white/90 backdrop-blur-sm rounded-3xl p-6 shadow-xl hover:shadow-2xl transition-all duration-300 hover:scale-105">
              <div className="w-16 h-16 rounded-2xl bg-gradient-to-r from-purple-500 to-indigo-600 flex items-center justify-center mb-4 mx-auto shadow-lg">
                <i className="ri-user-heart-fill text-white text-2xl"></i>
              </div>
              <h3 className="font-bold text-gray-800 mb-2 text-center">شوگر دیدی</h3>
              <p className="text-sm text-gray-600 text-center leading-relaxed">ارتباط با افراد موفق و ثروتمند</p>
            </div>
            
            <div className="bg-white/90 backdrop-blur-sm rounded-3xl p-6 shadow-xl hover:shadow-2xl transition-all duration-300 hover:scale-105">
              <div className="w-16 h-16 rounded-2xl bg-gradient-to-r from-blue-500 to-cyan-600 flex items-center justify-center mb-4 mx-auto shadow-lg">
                <i className="ri-message-3-fill text-white text-2xl"></i>
              </div>
              <h3 className="font-bold text-gray-800 mb-2 text-center">چت امن</h3>
              <p className="text-sm text-gray-600 text-center leading-relaxed">گفتگوی امن و محرمانه</p>
            </div>
            
            <div className="bg-white/90 backdrop-blur-sm rounded-3xl p-6 shadow-xl hover:shadow-2xl transition-all duration-300 hover:scale-105">
              <div className="w-16 h-16 rounded-2xl bg-gradient-to-r from-green-500 to-emerald-600 flex items-center justify-center mb-4 mx-auto shadow-lg">
                <i className="ri-shield-check-fill text-white text-2xl"></i>
              </div>
              <h3 className="font-bold text-gray-800 mb-2 text-center">تایید هویت</h3>
              <p className="text-sm text-gray-600 text-center leading-relaxed">تمام کاربران تایید هویت شده</p>
            </div>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="px-6 mb-8">
          <h2 className="text-2xl font-bold text-gray-800 mb-6 text-center">شروع کنید</h2>
          <div className="space-y-4">
            <button onClick={() => navigate('/services')} className="block w-full">
              <div className="bg-gradient-to-r from-pink-500 to-rose-600 rounded-2xl p-6 shadow-xl hover:shadow-2xl transition-all duration-300 hover:scale-[1.02]">
                <div className="flex items-center">
                  <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center mr-4">
                    <i className="ri-heart-fill text-white text-xl"></i>
                  </div>
                  <div className="flex-1">
                    <h3 className="text-white font-bold text-lg">مشاهده کیس‌ها</h3>
                    <p className="text-white/80 text-sm">پروفایل‌های تایید شده را ببینید</p>
                  </div>
                  <i className="ri-arrow-left-line text-white text-xl"></i>
                </div>
              </div>
            </button>

            {/* Inquiry Section */}
            <div className="bg-white/90 backdrop-blur-sm rounded-3xl p-6 shadow-xl mb-6">
              <h3 className="font-bold text-gray-800 text-lg mb-4 flex items-center">
                <i className="ri-chat-3-line ml-2 text-pink-600"></i>
                چت و ارتباط
              </h3>
              <p className="text-gray-600 text-sm mb-4 leading-relaxed">
                برای چت با کیس‌های خود، کد یکتا را وارد کنید
              </p>
              
              <div className="space-y-4">
                <div>
                  <label className="block text-gray-700 text-sm font-medium mb-2">کد یکتا کیس</label>
                  <div className="relative">
                    <input
                      type="text"
                      value={uniqueCodeInput}
                      onChange={(e) => setUniqueCodeInput(e.target.value)}
                      placeholder="مثال: C1234-567"
                      className="w-full bg-gray-50 border border-gray-200 rounded-2xl px-4 py-3 pr-12 focus:outline-none focus:ring-2 focus:ring-pink-500 focus:border-transparent text-sm"
                    />
                    <i className="ri-qr-code-line absolute right-4 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
                  </div>
                </div>
                
                <button onClick={startChatFromHome} className="w-full bg-gradient-to-r from-pink-600 via-rose-600 to-purple-600 hover:from-pink-700 hover:via-rose-700 hover:to-purple-700 text-white font-bold py-3 px-6 rounded-2xl shadow-lg transition-all duration-300">
                  <i className="ri-chat-heart-line ml-2"></i>
                  شروع چت
                </button>
              </div>
            </div>

            <button onClick={() => navigate('/chat')} className="block w-full">
              <div className="bg-gradient-to-r from-purple-500 to-indigo-600 rounded-2xl p-6 shadow-xl hover:shadow-2xl transition-all duration-300 hover:scale-[1.02]">
                <div className="flex items-center">
                  <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center mr-4">
                    <i className="ri-message-3-fill text-white text-xl"></i>
                  </div>
                  <div className="flex-1">
                    <h3 className="text-white font-bold text-lg">شروع چت</h3>
                    <p className="text-white/80 text-sm">با افراد مورد نظر چت کنید</p>
                  </div>
                  <i className="ri-arrow-left-line text-white text-xl"></i>
                </div>
              </div>
            </button>
          </div>
        </div>

        {/* **بخش جدید: آگهی‌های اخیر با دکمه بارگذاری** */}
        <div className="px-6">
          <h2 className="text-2xl font-bold text-gray-800 mb-6 text-center">آخرین آگهی‌ها</h2>
          
          {/* نمایش وضعیت */}
          {totalCases === 0 ? (
            <div className="bg-white/90 backdrop-blur-sm rounded-3xl p-8 shadow-xl text-center">
              <div className="w-20 h-20 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center mx-auto mb-6">
                <i className="ri-database-line text-white text-3xl"></i>
              </div>
              <h3 className="text-xl font-bold text-gray-800 mb-3">آگهی‌ها آماده بارگذاری</h3>
              <p className="text-gray-600 mb-6 leading-relaxed">
                برای مشاهده آخرین آگهی‌های فعال از دیتابیس، دکمه زیر را کلیک کنید
              </p>
              <button
                onClick={loadRecentCasesAdvanced}
                disabled={loading}
                className="bg-gradient-to-r from-blue-600 to-indigo-700 hover:from-blue-700 hover:to-indigo-800 text-white font-bold py-4 px-8 rounded-2xl shadow-xl transition-all duration-300 hover:scale-105 disabled:opacity-50"
              >
                {loading ? (
                  <div className="flex items-center">
                    <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin ml-2"></div>
                    در حال بارگذاری...
                  </div>
                ) : (
                  <>
                    <i className="ri-download-cloud-line ml-2 text-xl"></i>
                    بارگذاری آگهی‌ها از دیتابیس
                  </>
                )}
              </button>
            </div>
          ) : (
            <div className="bg-white/90 backdrop-blur-sm rounded-3xl p-6 shadow-xl">
              <div className="text-center mb-4">
                <div className="flex items-center justify-center mb-2">
                  <div className="w-2 h-2 bg-green-500 rounded-full mr-2 animate-pulse"></div>
                  <span className="text-gray-600 text-sm">
                    <span className="font-bold text-blue-600">{totalCases}</span> آگهی فعال موجود
                  </span>
                </div>
                <button
                  onClick={loadRecentCasesAdvanced}
                  disabled={loading}
                  className="text-blue-600 hover:text-blue-800 text-sm font-medium transition-colors disabled:opacity-50"
                >
                  <i className="ri-refresh-line ml-1"></i>
                  رفرش از دیتابیس
                </button>
              </div>

              <div className="space-y-3 max-h-64 overflow-y-auto">
                {cases.slice(-5).reverse().map((caseItem) => (
                  <div
                    key={caseItem.id}
                    className="bg-gray-50 rounded-xl p-3 hover:bg-gray-100 transition-colors cursor-pointer"
                    onClick={() => navigate(`/case-details/${caseItem.id}`)}
                  >
                    <div className="flex items-center">
                      <img
                        src={caseItem.image}
                        alt={caseItem.name}
                        className="w-12 h-12 rounded-lg object-cover shadow-md mr-3"
                        onError={(e) => {
                          const target = e.target as HTMLImageElement;
                          target.src = `https://readdy.ai/api/search-image?query=Beautiful%20Persian%20woman%20portrait&width=100&height=100&seq=${caseItem.id}&orientation=portrait`;
                        }}
                      />
                      <div className="flex-1">
                        <p className="text-gray-800 font-medium text-sm flex items-center mb-1">
                          {caseItem.name}
                          {caseItem.verified && (
                            <i className="ri-verified-badge-line text-blue-500 text-xs mr-2"></i>
                          )}
                        </p>
                        <div className="text-gray-600 text-xs">
                          <span className="flex items-center">
                            <i className="ri-map-pin-line mr-1"></i>
                            {caseItem.location}
                            {caseItem.age && <span className="mr-2">• {caseItem.age} ساله</span>}
                          </span>
                        </div>
                      </div>
                      <div className="flex items-center">
                        <div className="bg-green-100 text-green-700 text-xs px-2 py-1 rounded-full">
                          فعال
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              <div className="text-center mt-4">
                <button
                  onClick={() => navigate('/services')}
                  className="bg-gradient-to-r from-pink-500 to-rose-600 hover:from-pink-600 hover:to-rose-700 text-white px-6 py-2 rounded-xl transition-all text-sm font-semibold"
                >
                  <i className="ri-eye-line ml-2"></i>
                  مشاهده تمام آگهی‌ها
                </button>
              </div>
            </div>
          )}
        </div>
      </div>

      <TabBar />
    </div>
  );
}
