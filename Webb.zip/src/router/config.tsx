import { lazy } from "react";
import type { RouteObject } from "react-router-dom";
import NotFound from "../pages/NotFound";

// Lazy load pages
const Home = lazy(() => import('../pages/home/page'));
const Services = lazy(() => import('../pages/services/page'));
const Chat = lazy(() => import('../pages/chat/page'));
const Profile = lazy(() => import('../pages/profile/page'));
const Payment = lazy(() => import('../pages/payment/page'));
const Verification = lazy(() => import('../pages/verification/page'));
const AdminLogin = lazy(() => import('../pages/admin/login/page'));
const AdminDashboard = lazy(() => import('../pages/admin/dashboard/page'));
const CaseDetails = lazy(() => import('../pages/case-details/page'));

const routes: RouteObject[] = [
  {
    path: '/',
    element: <Home />
  },
  {
    path: '/services',
    element: <Services />
  },
  {
    path: '/chat',
    element: <Chat />
  },
  {
    path: '/profile',
    element: <Profile />
  },
  {
    path: '/payment/:id',
    element: <Payment />
  },
  {
    path: '/verification/:id',
    element: <Verification />
  },
  {
    path: '/case-details/:id',
    element: <CaseDetails />
  },
  {
    path: '/admin/login',
    element: <AdminLogin />
  },
  {
    path: '/admin/dashboard',
    element: <AdminDashboard />
  },
  {
    path: '*',
    element: <NotFound />
  }
];

export default routes;