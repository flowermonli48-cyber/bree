import { useNavigate, useLocation } from 'react-router-dom';

export default function TabBar() {
  const navigate = useNavigate();
  const location = useLocation();

  const tabs = [
    { path: '/', icon: 'ri-home-line', label: 'خانه' },
    { path: '/services', icon: 'ri-file-list-3-line', label: 'آگهی‌ها' },
    { path: '/chat', icon: 'ri-chat-3-line', label: 'چت' },
    { path: '/profile', icon: 'ri-admin-line', label: 'پنل ادمین' },
  ];

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white/95 backdrop-blur-sm shadow-lg z-40 border-t border-gray-200/50">
      <div className="grid grid-cols-4 h-16">
        {tabs.map((tab) => (
          <button
            key={tab.path}
            onClick={() => navigate(tab.path)}
            className={`flex flex-col items-center justify-center space-y-1 transition-colors ${
              location.pathname === tab.path
                ? 'text-purple-600'
                : 'text-gray-500 hover:text-gray-700'
            }`}
          >
            <i className={`${tab.icon} text-xl`}></i>
            <span className="text-xs font-medium">{tab.label}</span>
          </button>
        ))}
      </div>
    </div>
  );
}